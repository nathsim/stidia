/**
 * content.js – Script de contenu injecté dans TikTok
 * Rôle : crée la bulle flottante et l'iframe du panneau latéral,
 *         gère toute la communication avec la sidebar.
 */

(function () {
  'use strict';

  // ─── Garde : n'injecter qu'une seule fois ─────────────────────────────────────
  if (document.getElementById('tiktok-ai-root')) return;

  // ─── Constantes ───────────────────────────────────────────────────────────────
  const SIDEBAR_URL  = chrome.runtime.getURL('sidebar.html');
  const PANEL_WIDTH  = '420px';
  const ANIM_DURATION = 280; // ms

  // ─── Création du conteneur racine ─────────────────────────────────────────────
  const root = document.createElement('div');
  root.id    = 'tiktok-ai-root';
  document.body.appendChild(root);

  // ─── Styles injectés dynamiquement (isolés du DOM TikTok) ────────────────────
  const style = document.createElement('style');
  style.textContent = `
    /* Bulle flottante */
    #tiktok-ai-bubble {
      position: fixed;
      bottom: 80px;
      left: 20px;
      width: 52px;
      height: 52px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7C3AED 0%, #A855F7 50%, #EC4899 100%);
      box-shadow: 0 4px 20px rgba(124, 58, 237, 0.45),
                  0 0 0 0 rgba(124, 58, 237, 0.4);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2147483646;
      transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1),
                  box-shadow 0.2s ease;
      animation: tai-pulse 2.5s ease-in-out infinite;
      user-select: none;
    }

    #tiktok-ai-bubble:hover {
      transform: scale(1.12);
      box-shadow: 0 6px 28px rgba(124, 58, 237, 0.6),
                  0 0 0 8px rgba(124, 58, 237, 0.12);
      animation: none;
    }

    #tiktok-ai-bubble:active {
      transform: scale(0.94);
    }

    #tiktok-ai-bubble svg {
      width: 26px;
      height: 26px;
      fill: #fff;
      stroke: none;
      pointer-events: none;
    }

    /* Badge notification */
    #tiktok-ai-badge {
      position: absolute;
      top: -3px;
      right: -3px;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #10B981;
      border: 2px solid #fff;
      font-size: 8px;
      font-weight: 700;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, sans-serif;
      opacity: 0;
      transform: scale(0);
      transition: opacity 0.2s, transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    #tiktok-ai-badge.visible {
      opacity: 1;
      transform: scale(1);
    }

    /* Tooltip */
    #tiktok-ai-tooltip {
      position: absolute;
      left: 62px;
      bottom: 50%;
      transform: translateY(50%);
      background: rgba(15, 15, 20, 0.92);
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 12px;
      font-weight: 500;
      padding: 6px 10px;
      border-radius: 8px;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.15s ease;
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255,255,255,0.08);
    }

    #tiktok-ai-bubble:hover #tiktok-ai-tooltip {
      opacity: 1;
    }

    /* Panneau latéral (iframe) */
    #tiktok-ai-panel {
      position: fixed;
      top: 0;
      right: 0;
      width: ${PANEL_WIDTH};
      height: 100vh;
      z-index: 2147483645;
      box-shadow: -8px 0 40px rgba(0, 0, 0, 0.25);
      transform: translateX(100%);
      transition: transform ${ANIM_DURATION}ms cubic-bezier(0.4, 0, 0.2, 1);
      border: none;
      border-radius: 0;
      overflow: hidden;
      background: transparent;
    }

    #tiktok-ai-panel.open {
      transform: translateX(0);
    }

    /* Overlay semi-transparent */
    #tiktok-ai-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(2px);
      z-index: 2147483644;
      opacity: 0;
      pointer-events: none;
      transition: opacity ${ANIM_DURATION}ms ease;
    }

    #tiktok-ai-overlay.visible {
      opacity: 1;
      pointer-events: all;
    }

    /* Animation de pulsation de la bulle */
    @keyframes tai-pulse {
      0%, 100% {
        box-shadow: 0 4px 20px rgba(124, 58, 237, 0.45),
                    0 0 0 0 rgba(124, 58, 237, 0.4);
      }
      50% {
        box-shadow: 0 4px 20px rgba(124, 58, 237, 0.45),
                    0 0 0 10px rgba(124, 58, 237, 0);
      }
    }
  `;
  document.head.appendChild(style);

  // ─── DOM : Overlay ─────────────────────────────────────────────────────────────
  const overlay = document.createElement('div');
  overlay.id    = 'tiktok-ai-overlay';
  root.appendChild(overlay);

  // ─── DOM : Panneau (iframe) ────────────────────────────────────────────────────
  const panel     = document.createElement('iframe');
  panel.id        = 'tiktok-ai-panel';
  panel.src       = SIDEBAR_URL;
  panel.title     = 'Stidia';
  panel.setAttribute('sandbox', [
    'allow-scripts',
    'allow-same-origin',
    'allow-forms',
    'allow-popups',
    'allow-downloads',
    'allow-popups-to-escape-sandbox',
    'allow-modals',
  ].join(' '));
  panel.setAttribute('allow', 'fullscreen');
  root.appendChild(panel);

  // ─── DOM : Bulle flottante ────────────────────────────────────────────────────
  const bubble = document.createElement('div');
  bubble.id    = 'tiktok-ai-bubble';
  bubble.setAttribute('role', 'button');
  bubble.setAttribute('aria-label', 'Ouvrir Stidia');
  bubble.setAttribute('tabindex', '0');

  // Icône IA (SVG inline)
  bubble.innerHTML = `
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M13.6 4.4 L7.7 13.1 h3.5 l-0.9 6.5 6.1 -8.9 h-3.6 z"/>
    </svg>
    <div id="tiktok-ai-badge" aria-hidden="true"></div>
    <div id="tiktok-ai-tooltip">Stidia</div>
  `;
  root.appendChild(bubble);

  // ─── État ─────────────────────────────────────────────────────────────────────
  let isPanelOpen = false;

  // ─── Fonctions ────────────────────────────────────────────────────────────────

  /**
   * Ouvre le panneau latéral avec animation.
   */
  function openPanel() {
    isPanelOpen = true;
    panel.classList.add('open');
    overlay.classList.add('visible');
    bubble.setAttribute('aria-expanded', 'true');

    // Envoie un signal à la sidebar pour qu'elle sache qu'elle est visible
    sendToSidebar({ action: 'PANEL_OPENED' });
  }

  /**
   * Ferme le panneau latéral avec animation.
   */
  function closePanel() {
    isPanelOpen = false;
    panel.classList.remove('open');
    overlay.classList.remove('visible');
    bubble.setAttribute('aria-expanded', 'false');

    sendToSidebar({ action: 'PANEL_CLOSED' });
  }

  /**
   * Envoie un message à l'iframe de la sidebar via postMessage.
   */
  function sendToSidebar(message) {
    if (panel.contentWindow) {
      panel.contentWindow.postMessage(
        { source: 'tiktok-ai-content', ...message },
        chrome.runtime.getURL('').slice(0, -1) // origin de l'extension
      );
    }
  }

  /**
   * Met à jour le badge de notification.
   */
  function updateBadge(count) {
    const badge = document.getElementById('tiktok-ai-badge');
    if (!badge) return;
    if (count > 0) {
      badge.textContent = count > 9 ? '9+' : String(count);
      badge.classList.add('visible');
    } else {
      badge.classList.remove('visible');
    }
  }

  // ─── Listeners de la bulle ────────────────────────────────────────────────────

  bubble.addEventListener('click', () => {
    isPanelOpen ? closePanel() : openPanel();
  });

  // Accessibilité clavier
  bubble.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      isPanelOpen ? closePanel() : openPanel();
    }
  });

  // Fermeture via l'overlay
  overlay.addEventListener('click', closePanel);

  // Fermeture via la touche Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isPanelOpen) closePanel();
  });

  // ─── Réception de messages depuis la sidebar ──────────────────────────────────
  window.addEventListener('message', (event) => {
    // Vérifie l'origine : l'iframe vient de l'extension
    if (!event.data || event.data.source !== 'tiktok-ai-sidebar') return;

    const { action, payload } = event.data;

    switch (action) {
      case 'CLOSE_PANEL':
        closePanel();
        break;

      case 'UPDATE_BADGE':
        updateBadge(payload?.count || 0);
        break;

      case 'GET_PAGE_CONTEXT':
        // Fournit des infos contextuelles sur la page TikTok en cours
        sendToSidebar({
          action:  'PAGE_CONTEXT',
          payload: getPageContext(),
        });
        break;

      default:
        break;
    }
  });

  // ─── Contexte TikTok ──────────────────────────────────────────────────────────

  /**
   * Extrait des informations contextuelles depuis la page TikTok.
   * Utilisé pour enrichir les prompts automatiquement.
   */
  function getPageContext() {
    const ctx = {
      url:      window.location.href,
      pathname: window.location.pathname,
    };

    // Détection du type de page
    if (ctx.pathname.startsWith('/@')) {
      ctx.type    = 'profile';
      ctx.creator = ctx.pathname.slice(2).split('/')[0];
    } else if (ctx.pathname.includes('/video/')) {
      ctx.type = 'video';
      // Tente d'extraire la description de la vidéo
      const desc = document.querySelector('[data-e2e="video-desc"]');
      if (desc) ctx.videoDescription = desc.innerText.trim().slice(0, 200);
    } else if (ctx.pathname === '/') {
      ctx.type = 'feed';
    } else {
      ctx.type = 'other';
    }

    return ctx;
  }

  // ─── Relais des messages API vers le background ───────────────────────────────
  // La sidebar ne peut pas parler directement au background (iframe cross-origin
  // avec service worker), donc content.js fait le relais.

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Messages qui viennent du background vers la sidebar (ex: mise à jour)
    if (message.action === 'REFRESH_SIDEBAR') {
      sendToSidebar({ action: 'REFRESH' });
    }
    return false;
  });

  console.log('[Stidia] Content script chargé ✓');
})();
