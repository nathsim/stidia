/**
 * dashboard-bridge.js – Pont sécurisé entre le dashboard du site Stidia
 * et l'extension installée.
 *
 * Injecté UNIQUEMENT sur la page dashboard du site officiel (voir manifest).
 * La page ne peut appeler qu'une liste blanche d'actions ; les réponses ne
 * contiennent jamais de clés API ni de mots de passe (voir dashLogin).
 */

(function () {
  'use strict';

  const PAGE_SOURCE = 'stidia-dashboard';   // messages émis par la page
  const EXT_SOURCE  = 'stidia-extension';   // messages émis par ce pont
  const ALLOWED     = new Set([
    'DASH_LOGIN', 'DASH_REGISTER', 'DASH_WHOAMI',
    'ADMIN_LIST_ACCOUNTS', 'ADMIN_SET_PLAN', 'ADMIN_DELETE_ACCOUNT',
  ]);

  window.addEventListener('message', (event) => {
    // N'accepte que les messages de la page elle-même (même fenêtre, même origine)
    if (event.source !== window) return;
    const d = event.data;
    if (!d || d.source !== PAGE_SOURCE || !d.action) return;

    // Ping local : permet à la page de détecter l'extension à tout moment
    if (d.action === 'DASH_PING') {
      window.postMessage({
        source: EXT_SOURCE,
        reqId:  d.reqId,
        response: { success: true, ready: true, version: chrome.runtime.getManifest().version },
      }, window.location.origin);
      return;
    }

    if (!ALLOWED.has(d.action)) return;

    chrome.runtime.sendMessage({ action: d.action, payload: d.payload }, (response) => {
      const payload = chrome.runtime.lastError
        ? { success: false, error: 'Extension indisponible. Recharge la page.' }
        : response;
      window.postMessage({ source: EXT_SOURCE, reqId: d.reqId, response: payload }, window.location.origin);
    });
  });

  // Annonce la présence de l'extension dès l'injection
  window.postMessage({
    source: EXT_SOURCE,
    ready:  true,
    version: chrome.runtime.getManifest().version,
  }, window.location.origin);
})();
