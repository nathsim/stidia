/**
 * background.js – Service Worker (Manifest V3)
 * Rôle : authentification, relais API IA, storage par compte.
 */

// ─── Constantes ────────────────────────────────────────────────────────────────
const STORAGE_KEYS = {
  ACCOUNTS: 'tiktok_ai_accounts',
};

const DEFAULT_SETTINGS = {
  model:      'llama-3.3-70b-versatile',
  language:   'fr',
  maxHistory: 20,
};

const SALT = 'tiktok_ai_studio_2024';

// ─── Initialisation ─────────────────────────────────────────────────────────────
// La session de connexion est conservée dans chrome.storage.local (persistante) :
// pas d'effacement automatique au démarrage ou au rechargement de l'extension.

// ─── Récepteur de messages ──────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((err) => sendResponse({ success: false, error: err.message }));
  return true;
});

async function handleMessage(message) {
  const { action, payload } = message;
  switch (action) {
    case 'REGISTER':            return await register(payload);
    case 'LOGIN':               return await login(payload);
    case 'LOGOUT':              return await logout();
    case 'GET_SESSION':         return await getSession();
    case 'GENERATE_CONTENT':    return await generateContent(payload);
    case 'GET_SETTINGS':        return await getSettings();
    case 'SAVE_SETTINGS':       return await saveSettings(payload);
    case 'GET_HISTORY':         return await getHistory();
    case 'SAVE_HISTORY_ENTRY':  return await saveHistoryEntry(payload);
    case 'CLEAR_HISTORY':       return await clearHistory();
    case 'DELETE_HISTORY_ENTRY':return await deleteHistoryEntry(payload.id);
    case 'GET_VIDEO_KEY':       return await getVideoKey();
    case 'SAVE_VIDEO_KEY':      return await saveVideoKey(payload);
    case 'ACTIVATE_LICENSE':    return await activateLicense(payload);
    case 'DASH_LOGIN':          return await dashLogin(payload);
    case 'DASH_REGISTER':       return await dashRegister(payload);
    case 'ADMIN_LIST_ACCOUNTS': return await adminListAccounts(payload);
    case 'ADMIN_SET_PLAN':      return await adminSetPlan(payload);
    case 'ADMIN_DELETE_ACCOUNT':return await adminDeleteAccount(payload);
    default: return { success: false, error: `Action inconnue : ${action}` };
  }
}

// ─── Panel admin/staff (réservé au propriétaire) ────────────────────────────────
// Protection par passphrase séparée des comptes utilisateurs. Le hash ci-dessous
// correspond à la passphrase communiquée uniquement au propriétaire — jamais en
// clair dans le code. Pour la changer : recalculer sha256(nouvellePassphrase + ADMIN_SALT).
const ADMIN_SALT      = 'stidia_admin_2026_ne_pas_partager';
const ADMIN_KEY_HASH  = '0457bb92eb04f61db142c957d299a6710bb766117e6c953f7f3eea7d19d823a3';

async function hashAdminKey(key) {
  const encoder = new TextEncoder();
  const data = encoder.encode(String(key || '') + ADMIN_SALT);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function requireAdmin(adminKey) {
  const h = await hashAdminKey(adminKey);
  if (h !== ADMIN_KEY_HASH) throw new Error('Clé administrateur invalide.');
}

/** Liste les comptes stockés dans CE navigateur (jamais de mot de passe ni de clés API en clair). */
async function adminListAccounts({ adminKey } = {}) {
  await requireAdmin(adminKey);
  const accounts = await getAccounts();
  const out = [];
  for (const a of accounts) {
    const { history } = await getHistory(a.username);
    out.push({
      username:     a.username,
      plan:         a.plan || 'free',
      createdAt:    a.createdAt,
      hasGroqKey:   !!a.apiKey,
      hasPexelsKey: !!a.videoKey,
      historyCount: history.length,
      licenseCode:  a.licenseCode || null,
    });
  }
  return { success: true, accounts: out };
}

/** Change l'offre d'un compte directement (sans code) — outil admin uniquement. */
async function adminSetPlan({ adminKey, username, plan } = {}) {
  await requireAdmin(adminKey);
  if (!(plan in PLAN_ORDER)) throw new Error('Offre invalide.');
  const accounts = await getAccounts();
  const idx = accounts.findIndex(a => a.username === username);
  if (idx === -1) throw new Error('Compte introuvable.');
  accounts[idx].plan = plan;
  await saveAccounts(accounts);
  return { success: true };
}

/** Supprime un compte de test (et son historique/quota) de ce navigateur. */
async function adminDeleteAccount({ adminKey, username } = {}) {
  await requireAdmin(adminKey);
  const accounts = await getAccounts();
  const idx = accounts.findIndex(a => a.username === username);
  if (idx === -1) throw new Error('Compte introuvable.');
  accounts.splice(idx, 1);
  await saveAccounts(accounts);
  const histKey   = await historyKey(username);
  const quotaKey  = `tiktok_ai_quota_${username}`;
  await chrome.storage.local.remove([histKey, quotaKey]);
  return { success: true };
}

// ─── Dashboard web (via le pont dashboard-bridge.js sur le site) ───────────────

/** Construit le profil public (sans clés ni hash) renvoyé au dashboard web. */
async function buildDashProfile(account) {
  const plan = account.plan || 'free';
  const { history } = await getHistory(account.username);

  const today    = new Date().toISOString().slice(0, 10);
  const quotaKey = `tiktok_ai_quota_${account.username}`;
  const qd       = await chrome.storage.local.get(quotaKey);
  const todayCount = qd[quotaKey]?.date === today ? qd[quotaKey].count : 0;

  // Activité des 14 derniers jours (pour le mini graphique du dashboard)
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    days.push({ date: d, count: history.filter(e => e.createdAt?.slice(0, 10) === d).length });
  }

  return {
    username:         account.username,
    plan,
    createdAt:        account.createdAt,
    totalGenerations: history.length,
    todayCount,
    quotaLeft:        plan === 'free' ? Math.max(0, FREE_DAILY_LIMIT - todayCount) : null,
    hasGroqKey:       !!account.apiKey,
    hasPexelsKey:     !!account.videoKey,
    licenseCode:      account.licenseCode || null,
    activity:         days,
    recent: history.slice(0, 5).map(e => ({
      prompt:    (e.prompt || '').slice(0, 90),
      createdAt: e.createdAt,
    })),
  };
}

/**
 * Connexion depuis le dashboard du site : vérifie les identifiants et renvoie
 * un profil SANS données sensibles (jamais de clés API ni de hash).
 */
async function dashLogin({ username, password }) {
  if (!username || !password)
    throw new Error('Identifiant et mot de passe requis.');

  const accounts = await getAccounts();
  const account  = accounts.find(a => a.username.toLowerCase() === String(username).trim().toLowerCase());
  if (!account) throw new Error('Nom d\'utilisateur introuvable.');

  const passwordHash = await hashPassword(password);
  if (passwordHash !== account.passwordHash)
    throw new Error('Mot de passe incorrect.');

  return { success: true, profile: await buildDashProfile(account) };
}

/**
 * Création de compte depuis le dashboard du site : mêmes règles que l'inscription
 * dans l'extension, MAIS ne change jamais la session active du panneau (contrairement
 * à register()) — créer un compte depuis le site ne doit pas déconnecter l'utilisateur
 * de son compte en cours sur TikTok.
 */
async function dashRegister({ username, password, apiKey }) {
  if (!username || username.trim().length < 3)
    throw new Error('Le nom d\'utilisateur doit faire au moins 3 caractères.');
  if (!password || password.length < 6)
    throw new Error('Le mot de passe doit faire au moins 6 caractères.');
  if (!apiKey || !apiKey.startsWith('gsk_'))
    throw new Error('Clé API Groq invalide. Elle doit commencer par gsk_');

  const accounts = await getAccounts();
  if (accounts.find(a => a.username.toLowerCase() === username.trim().toLowerCase()))
    throw new Error('Ce nom d\'utilisateur est déjà pris.');

  const passwordHash = await hashPassword(password);
  const newAccount = {
    username:     username.trim(),
    passwordHash,
    apiKey,
    model:        DEFAULT_SETTINGS.model,
    language:     DEFAULT_SETTINGS.language,
    maxHistory:   DEFAULT_SETTINGS.maxHistory,
    createdAt:    new Date().toISOString(),
  };

  accounts.push(newAccount);
  await saveAccounts(accounts);

  return { success: true, profile: await buildDashProfile(newAccount) };
}

// ─── Offres & licences ──────────────────────────────────────────────────────────
// Plans : free (Découverte) < creator (Créateur) < viral (Viral) < studio (Studio)

const PLAN_ORDER = { free: 0, creator: 1, viral: 2, studio: 3 };
const FREE_DAILY_LIMIT = 3;

const LICENSE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const LICENSE_TIERS = { CREA: 'creator', VIRAL: 'viral', STUDIO: 'studio' };

/**
 * Valide un code du format STIDIA-<TIER>-XXXX-XXXX dont le dernier caractère
 * est une somme de contrôle des caractères précédents.
 */
function validateLicense(rawCode) {
  const code = String(rawCode || '').trim().toUpperCase();
  const m = code.match(/^STIDIA-(CREA|VIRAL|STUDIO)-([A-Z0-9]{4})-([A-Z0-9]{4})$/);
  if (!m) return null;
  const body = code.slice(0, -1);
  let sum = 0;
  for (let i = 0; i < body.length; i++) sum += body.charCodeAt(i) * (i + 1);
  const expected = LICENSE_ALPHABET[sum % 36];
  if (code[code.length - 1] !== expected) return null;
  return LICENSE_TIERS[m[1]] || null;
}

async function activateLicense({ code }) {
  const username = await getCurrentUsername();
  if (!username) throw new Error('Non connecté.');

  const plan = validateLicense(code);
  if (!plan) throw new Error('Code invalide. Vérifie qu\'il est bien recopié (format STIDIA-…).');

  const accounts = await getAccounts();
  const idx = accounts.findIndex(a => a.username === username);
  if (idx === -1) throw new Error('Compte introuvable.');

  accounts[idx].plan = plan;
  accounts[idx].licenseCode = String(code).trim().toUpperCase();
  await saveAccounts(accounts);
  return { success: true, plan };
}

/** Quota quotidien du plan gratuit (3 générations / jour). */
async function checkDailyQuota(username, plan) {
  if (PLAN_ORDER[plan] > 0) return; // plans payants : illimité
  const key   = `tiktok_ai_quota_${username}`;
  const today = new Date().toISOString().slice(0, 10);
  const data  = await chrome.storage.local.get(key);
  const q     = data[key]?.date === today ? data[key] : { date: today, count: 0 };
  if (q.count >= FREE_DAILY_LIMIT) {
    throw new Error(`Limite gratuite atteinte (${FREE_DAILY_LIMIT} générations/jour). ` +
      'Passe à l\'offre Créateur pour générer sans limite — code d\'activation dans les Paramètres.');
  }
  q.count++;
  await chrome.storage.local.set({ [key]: q });
}

// ─── Utilitaires ───────────────────────────────────────────────────────────────

async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + SALT);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getAccounts() {
  const data = await chrome.storage.local.get(STORAGE_KEYS.ACCOUNTS);
  return data[STORAGE_KEYS.ACCOUNTS] || [];
}

async function saveAccounts(accounts) {
  await chrome.storage.local.set({ [STORAGE_KEYS.ACCOUNTS]: accounts });
}

async function getSession() {
  try {
    const data = await chrome.storage.local.get('currentUser');
    return { success: true, username: data.currentUser || null };
  } catch {
    return { success: true, username: null };
  }
}

async function getCurrentUsername() {
  const { username } = await getSession();
  return username;
}

// ─── Authentification ───────────────────────────────────────────────────────────

async function register({ username, password, apiKey }) {
  if (!username || username.trim().length < 3)
    throw new Error('Le nom d\'utilisateur doit faire au moins 3 caractères.');
  if (!password || password.length < 6)
    throw new Error('Le mot de passe doit faire au moins 6 caractères.');
  if (!apiKey || !apiKey.startsWith('gsk_'))
    throw new Error('Clé API Groq invalide. Elle doit commencer par gsk_');

  const accounts = await getAccounts();
  if (accounts.find(a => a.username.toLowerCase() === username.trim().toLowerCase()))
    throw new Error('Ce nom d\'utilisateur est déjà pris.');

  const passwordHash = await hashPassword(password);
  const newAccount = {
    username:     username.trim(),
    passwordHash,
    apiKey,
    model:        DEFAULT_SETTINGS.model,
    language:     DEFAULT_SETTINGS.language,
    maxHistory:   DEFAULT_SETTINGS.maxHistory,
    createdAt:    new Date().toISOString(),
  };

  accounts.push(newAccount);
  await saveAccounts(accounts);
  await chrome.storage.local.set({ currentUser: newAccount.username });

  return { success: true, username: newAccount.username };
}

async function login({ username, password }) {
  if (!username || !password)
    throw new Error('Identifiant et mot de passe requis.');

  const accounts = await getAccounts();
  const account  = accounts.find(a => a.username.toLowerCase() === username.trim().toLowerCase());

  if (!account) throw new Error('Nom d\'utilisateur introuvable.');

  const passwordHash = await hashPassword(password);
  if (passwordHash !== account.passwordHash)
    throw new Error('Mot de passe incorrect.');

  await chrome.storage.local.set({ currentUser: account.username });
  return { success: true, username: account.username };
}

async function logout() {
  await chrome.storage.local.remove('currentUser');
  return { success: true };
}

// ─── Paramètres (par compte) ────────────────────────────────────────────────────

async function getSettings() {
  const username = await getCurrentUsername();
  if (!username) throw new Error('Non connecté.');

  const accounts = await getAccounts();
  const account  = accounts.find(a => a.username === username);
  if (!account) throw new Error('Compte introuvable.');

  return {
    success:    true,
    apiKey:     account.apiKey,
    model:      account.model     || DEFAULT_SETTINGS.model,
    language:   account.language  || DEFAULT_SETTINGS.language,
    maxHistory: account.maxHistory || DEFAULT_SETTINGS.maxHistory,
    username:   account.username,
    plan:       account.plan || 'free',
  };
}

async function saveSettings(newSettings) {
  const username = await getCurrentUsername();
  if (!username) throw new Error('Non connecté.');

  const accounts = await getAccounts();
  const idx      = accounts.findIndex(a => a.username === username);
  if (idx === -1) throw new Error('Compte introuvable.');

  const allowed = ['apiKey', 'model', 'language', 'maxHistory'];
  allowed.forEach(k => {
    if (newSettings[k] !== undefined) accounts[idx][k] = newSettings[k];
  });

  await saveAccounts(accounts);
  return { success: true };
}

// ─── Génération IA ──────────────────────────────────────────────────────────────

async function generateContent({ prompt, steps = [], images = [] }) {
  const settings = await getSettings();

  if (!settings.apiKey)
    throw new Error('Aucune clé API configurée.');

  // Quota quotidien de l'offre gratuite
  await checkDailyQuota(settings.username, settings.plan);

  const systemPrompt = buildSystemPrompt(settings.language, steps);
  const hasImages    = images && images.length > 0;

  // Modèle vision quand des images sont jointes (le modèle texte ne peut pas les lire)
  const model = hasImages ? 'meta-llama/llama-4-scout-17b-16e-instruct' : settings.model;

  const userContent = hasImages
    ? [
        { type: 'text', text: prompt },
        ...images.slice(0, 4).map(dataUrl => ({ type: 'image_url', image_url: { url: dataUrl } })),
      ]
    : prompt;

  const body = {
    model,
    max_tokens:  2048,
    temperature: 0.8,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user',   content: userContent },
    ],
  };

  // Timeout : sans ça, une API qui ne répond pas bloque la génération indéfiniment
  const controller = new AbortController();
  const timeoutId  = setTimeout(() => controller.abort(), 60000);

  let response;
  try {
    response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${settings.apiKey}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (err) {
    if (err.name === 'AbortError')
      throw new Error('Délai dépassé : le serveur IA n\'a pas répondu. Réessaie.');
    throw new Error('Connexion impossible au serveur IA. Vérifie ta connexion.');
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Erreur HTTP ${response.status}`);
  }

  const data    = await response.json();
  const content = data.choices?.[0]?.message?.content?.trim() || '';

  // La sauvegarde d'historique ne doit jamais faire perdre un contenu déjà généré (quota storage).
  // On fige le compte (settings.username) pour ne pas écrire sous 'guest' si la session change.
  await saveHistoryEntry({
    id:        crypto.randomUUID(),
    prompt,
    result:    content,
    model,
    createdAt: new Date().toISOString(),
  }, settings.username).catch(err => console.warn('[Stidia] Échec sauvegarde historique :', err));

  return { success: true, content };
}

function buildSystemPrompt(language, steps) {
  const langs = { fr: 'français', en: 'English', es: 'español', de: 'Deutsch', pt: 'português' };
  const lang = langs[language] || 'français';
  const base = `Tu es un expert en création de contenu TikTok viral.
Réponds TOUJOURS en ${lang}.
Structure ta réponse avec des sections claires :
1. 🎬 CONCEPT & HOOK (accroche des 3 premières secondes)
2. 📝 SCRIPT COMPLET (dialogues, voix off, textes à l'écran)
3. 🎵 MUSIQUE & SON (suggestions de trending sounds)
4. 🎨 VISUELS & TRANSITIONS (descriptions de plans)
5. #️⃣ HASHTAGS (20 hashtags stratégiques)
6. ⏱️ TIMING (découpage seconde par seconde)
7. 💡 CONSEILS PRO (optimisation pour l'algorithme TikTok)

IMPORTANT : termine TOUJOURS ta réponse par UNE seule ligne, exactement au format :
MOTS-CLES-VIDEO: keyword1, keyword2, keyword3, keyword4
→ 4 mots-clés VISUELS et CONCRETS en ANGLAIS simple (2 mots max chacun), décrivant des plans filmables pour une banque de vidéos (ex: cat closeup, city night, laptop work, ocean waves). Jamais de mots abstraits.`;
  const extras = steps.map(s => `\n[MODULE ${s.id}] ${s.instruction}`).join('');
  return base + extras;
}

// ─── Vidéo IA (HuggingFace) ───────────────────────────────────────────────────

async function getVideoKey() {
  const username = await getCurrentUsername();
  if (!username) return { success: true, videoKey: null };
  const accounts = await getAccounts();
  const account  = accounts.find(a => a.username === username);
  return { success: true, videoKey: account?.videoKey || null };
}

async function saveVideoKey({ videoKey }) {
  const username = await getCurrentUsername();
  if (!username) throw new Error('Non connecté.');
  const accounts = await getAccounts();
  const idx = accounts.findIndex(a => a.username === username);
  if (idx === -1) throw new Error('Compte introuvable.');
  accounts[idx].videoKey = videoKey;
  await saveAccounts(accounts);
  return { success: true };
}

// ─── Historique (par compte) ────────────────────────────────────────────────────

async function historyKey(username) {
  const u = username || await getCurrentUsername();
  return `tiktok_ai_history_${u || 'guest'}`;
}

async function getHistory(username) {
  const key  = await historyKey(username);
  const data = await chrome.storage.local.get(key);
  return { success: true, history: data[key] || [] };
}

async function saveHistoryEntry(entry, username) {
  const key      = await historyKey(username);
  const settings = await getSettings().catch(() => DEFAULT_SETTINGS);
  // Offre gratuite : historique plafonné à 10 entrées
  const cap = (settings.plan || 'free') === 'free'
    ? Math.min(10, settings.maxHistory)
    : settings.maxHistory;
  const { history } = await getHistory(username);
  let updated = [entry, ...history].slice(0, cap);
  try {
    await chrome.storage.local.set({ [key]: updated });
  } catch (err) {
    // Quota dépassé : on purge agressivement les anciennes entrées et on réessaie
    updated = updated.slice(0, Math.max(5, Math.floor(updated.length / 2)));
    try {
      await chrome.storage.local.set({ [key]: updated });
    } catch {
      await chrome.storage.local.set({ [key]: [entry] });
    }
  }
  return { success: true };
}

async function clearHistory() {
  const key = await historyKey();
  await chrome.storage.local.set({ [key]: [] });
  return { success: true };
}

async function deleteHistoryEntry(id) {
  const key          = await historyKey();
  const { history }  = await getHistory();
  await chrome.storage.local.set({ [key]: history.filter(e => e.id !== id) });
  return { success: true };
}
