/**
 * sidebar.js – Logique du panneau latéral Stidia
 * Rôle : gère l'UI, les interactions, la communication avec background.js
 *        via chrome.runtime.sendMessage (relayé par content.js).
 *
 * Architecture :
 *   - App      : bootstrap, routing des messages
 *   - TabManager : gestion des onglets
 *   - Generator  : module de génération IA
 *   - History    : module historique
 *   - Settings   : module paramètres
 *   - Toast      : notifications légères
 *   - Utils      : helpers
 */

(function () {
  'use strict';

  /* ═══════════════════════════════════════════════════════════════════════════
     MODULES DISPONIBLES (étapes de génération)
     Chaque module peut être activé/désactivé par l'utilisateur.
     Extensible : ajouter un objet ici pour créer un nouveau module.
  ═══════════════════════════════════════════════════════════════════════════ */
  const AVAILABLE_MODULES = [
    {
      id:   'script',
      label: 'Script complet',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
              </svg>`,
      instruction: 'Fournis un script TikTok complet avec répliques et didascalies.',
      active: true,
    },
    {
      id:   'hashtags',
      label: 'Hashtags viraux',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="4" y1="9" x2="20" y2="9"/>
                <line x1="4" y1="15" x2="20" y2="15"/>
                <line x1="10" y1="3" x2="8" y2="21"/>
                <line x1="16" y1="3" x2="14" y2="21"/>
              </svg>`,
      instruction: 'Génère 30 hashtags ultra-ciblés pour maximiser la portée organique.',
      active: true,
    },
    {
      id:   'music',
      label: 'Musique & sons',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 18V5l12-2v13"/>
                <circle cx="6" cy="18" r="3"/>
                <circle cx="18" cy="16" r="3"/>
              </svg>`,
      instruction: 'Recommande 5 trending sounds TikTok avec le timing de placement.',
      active: true,
    },
    {
      id:   'hooks',
      label: '5 accroches',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
              </svg>`,
      instruction: 'Crée 5 variantes de hook (0-3 secondes) pour tester différentes accroches.',
      active: true,
    },
    {
      id:   'cta',
      label: 'Appels à l\'action',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
              </svg>`,
      instruction: 'Propose 3 CTA engageants adaptés à l\'objectif (follow, like, comment).',
      active: false,
    },
    {
      id:   'seo',
      label: 'SEO TikTok',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"/>
                <line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>`,
      instruction: 'Optimise la description, les mots-clés et la structure pour le moteur de recherche TikTok.',
      active: false,
    },
    {
      id:   'viral',
      label: 'Stratégie virale',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
                <polyline points="17 6 23 6 23 12"/>
              </svg>`,
      instruction: 'Analyse le potentiel viral et donne 5 conseils pour maximiser les partages et les vues.',
      active: false,
    },
    {
      id:   'thumbnail',
      label: 'Miniature',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
              </svg>`,
      instruction: 'Décris en détail la miniature idéale (couleurs, texte, composition) pour maximiser le taux de clic.',
      active: false,
    },
    {
      id:   'repurpose',
      label: 'Réutilisation',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="1 4 1 10 7 10"/>
                <polyline points="23 20 23 14 17 14"/>
                <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/>
              </svg>`,
      instruction: 'Adapte ce contenu pour Instagram Reels, YouTube Shorts et Snapchat Spotlight avec les spécificités de chaque plateforme.',
      active: false,
    },
    {
      id:   'storytelling',
      label: 'Storytelling',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
              </svg>`,
      instruction: 'Structure le contenu comme une histoire captivante : situation initiale, tension, rebondissement, résolution. Rend le spectateur incapable de scroller.',
      active: false,
    },
    {
      id:   'transitions',
      label: 'Transitions',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="2" y="3" width="8" height="18" rx="1"/>
                <rect x="14" y="3" width="8" height="18" rx="1"/>
                <line x1="10" y1="12" x2="14" y2="12"/>
              </svg>`,
      instruction: 'Propose 5 idées de transitions créatives et virales (cut, zoom, hands, spin, match cut) avec les instructions de tournage précises pour chaque plan.',
      active: false,
    },
    {
      id:   'controversy',
      label: 'Débat / Choc',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
              </svg>`,
      instruction: 'Crée un angle controversé ou choc qui provoque les commentaires et le débat, tout en restant dans les règles TikTok. Ajoute une opinion polarisante.',
      active: false,
    },
    {
      id:   'series',
      label: 'Série de contenu',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="2" y="7" width="20" height="15" rx="2"/>
                <polyline points="17 2 12 7 7 2"/>
              </svg>`,
      instruction: 'Transforme cette idée en une série de 5 épisodes TikTok avec un fil conducteur, des cliffhangers pour fidéliser l\'audience et des titres accrocheurs.',
      active: false,
    },
    {
      id:   'collab',
      label: 'Idées Collab',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>`,
      instruction: 'Propose 5 idées de collaboration avec d\'autres créateurs TikTok : type de créateur à cibler, concept de duet ou collab, et stratégie pour les contacter.',
      active: false,
    },
    {
      id:   'lowbudget',
      label: 'Tournage facile',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M23 7l-7 5 7 5V7z"/>
                <rect x="1" y="5" width="15" height="14" rx="2"/>
              </svg>`,
      instruction: 'Donne des conseils de tournage avec un smartphone uniquement : éclairage naturel, stabilisation, angle, décor simple. Budget 0€, résultat professionnel.',
      active: false,
    },
    {
      id:   'psychology',
      label: 'Psychologie',
      icon:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <path d="M12 8v4l3 3"/>
              </svg>`,
      instruction: 'Explique les biais cognitifs et déclencheurs psychologiques utilisés dans cette vidéo (curiosité, FOMO, validation sociale, urgence) pour maximiser l\'engagement.',
      active: false,
    },
  ];

  const TEMPLATES = [
    { emoji: '📦', label: 'Unboxing',    text: 'Crée une vidéo unboxing de 30 secondes sur [PRODUIT], avec une réaction authentique et suspense.' },
    { emoji: '💡', label: 'Astuce',      text: 'Partage une astuce de vie incroyable sur [SUJET] que personne ne connaît, format 15 secondes.' },
    { emoji: '🎭', label: 'POV',         text: 'Crée une vidéo POV drôle et relatable sur [SITUATION DU QUOTIDIEN], ton humoristique.' },
    { emoji: '⚗️', label: 'Avant/Après', text: 'Vidéo transformation avant/après sur [SUJET], 30 secondes, musique dramatique et résultat choc.' },
    { emoji: '🎓', label: 'Éducatif',    text: 'Explique [CONCEPT] en 60 secondes de façon simple et virale pour les 18-25 ans.' },
    { emoji: '🔥', label: 'Trend',       text: 'Adapte le trend TikTok du moment à [MON NICHE], avec les sons tendances actuels.' },
    { emoji: '😂', label: 'Humour',      text: 'Sketch comique de 30 secondes sur [SITUATION], avec un twist inattendu à la fin.' },
    { emoji: '💰', label: 'Produit',     text: 'Présente [PRODUIT] de façon authentique et convaincante en 30 secondes, style vlog naturel.' },
    { emoji: '🤖', label: 'Vidéo IA',   text: 'Crée un script pour une vidéo IA virale sur [SUJET] : visuels générés par IA, voix off synthétique, transitions futuristes. Optimisé pour dépasser 1M de vues.' },
  ];

  const SUGGESTIONS = [
    '🐱 Chats', '💪 Fitness', '🍕 Food', '✈️ Voyage', '💄 Beauté',
    '🎮 Gaming', '💸 Finance', '🌿 Nature', '📚 Études', '🎵 Musique',
    '👗 Mode', '🏠 Déco', '🐶 Animaux', '🧘 Bien-être', '📱 Tech',
    '🤖 Vidéo IA',
  ];

  /* ═══════════════════════════════════════════════════════════════════════════
     AUTH
  ═══════════════════════════════════════════════════════════════════════════ */
  const Auth = {
    init() {
      const goRegister = document.getElementById('go-register');
      const goLogin    = document.getElementById('go-login');
      const btnLogin   = document.getElementById('btn-login');
      const btnReg     = document.getElementById('btn-register');
      const btnLogout  = document.getElementById('btn-logout');

      goRegister?.addEventListener('click', () => this._showForm('register'));
      goLogin?.addEventListener('click',    () => this._showForm('login'));
      btnLogin?.addEventListener('click',   () => this._login());
      btnReg?.addEventListener('click',     () => this._register());
      btnLogout?.addEventListener('click',  () => this._logout());

      // Entrée clavier : valide depuis n'importe quel champ du formulaire
      ['login-username', 'login-password'].forEach(id => {
        document.getElementById(id)
          ?.addEventListener('keydown', e => { if (e.key === 'Enter') this._login(); });
      });
      ['reg-username', 'reg-password', 'reg-confirm', 'reg-apikey'].forEach(id => {
        document.getElementById(id)
          ?.addEventListener('keydown', e => { if (e.key === 'Enter') this._register(); });
      });

      // Boutons afficher/masquer mot de passe
      this._bindEye('login-eye', 'login-password');
      this._bindEye('reg-eye',   'reg-password');
    },

    _bindEye(btnId, inputId) {
      const btn   = document.getElementById(btnId);
      const input = document.getElementById(inputId);
      if (!btn || !input) return;
      btn.addEventListener('click', () => {
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.querySelector('svg').innerHTML = show
          ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8
             a18.45 18.45 0 0 1 5.06-5.94"/>
             <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8
             a18.5 18.5 0 0 1-2.16 3.19"/>
             <line x1="1" y1="1" x2="23" y2="23"/>`
          : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
             <circle cx="12" cy="12" r="3"/>`;
      });
    },

    _showForm(which) {
      document.getElementById('form-login').hidden    = which !== 'login';
      document.getElementById('form-register').hidden = which !== 'register';
      document.getElementById('login-error').hidden   = true;
      document.getElementById('reg-error').hidden     = true;
    },

    _setError(id, msg) {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = msg;
      el.hidden = false;
    },

    async _login() {
      const username = document.getElementById('login-username').value.trim();
      const password = document.getElementById('login-password').value;
      const btn      = document.getElementById('btn-login');
      document.getElementById('login-error').hidden = true;

      btn.disabled = true;
      btn.textContent = 'Connexion…';
      try {
        const res = await Utils.send('LOGIN', { username, password });
        if (res.success) App._onLogin(res.username);
        else this._setError('login-error', res.error || 'Erreur.');
      } catch (err) {
        this._setError('login-error', err.message);
      } finally {
        btn.disabled = false;
        btn.textContent = 'Se connecter';
      }
    },

    async _register() {
      const username = document.getElementById('reg-username').value.trim();
      const password = document.getElementById('reg-password').value;
      const confirm  = document.getElementById('reg-confirm').value;
      const apiKey   = document.getElementById('reg-apikey').value.trim();
      const btn      = document.getElementById('btn-register');
      document.getElementById('reg-error').hidden = true;

      if (password !== confirm) {
        this._setError('reg-error', 'Les mots de passe ne correspondent pas.');
        return;
      }

      btn.disabled = true;
      btn.textContent = 'Création…';
      try {
        const res = await Utils.send('REGISTER', { username, password, apiKey });
        if (res.success) App._onLogin(res.username);
        else this._setError('reg-error', res.error || 'Erreur.');
      } catch (err) {
        this._setError('reg-error', err.message);
      } finally {
        btn.disabled = false;
        btn.textContent = 'Créer mon compte';
      }
    },

    async _logout() {
      if (!confirm('Se déconnecter ?')) return;
      await Utils.send('LOGOUT');
      App._onLogout();
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     UTILS
  ═══════════════════════════════════════════════════════════════════════════ */
  const Utils = {
    // Origine réelle de la page hôte (TikTok), apprise au premier message reçu.
    // Évite d'envoyer nos postMessage avec le wildcard '*' (fuite cross-origin).
    _parentOrigin: null,

    /**
     * Envoie un message au parent (content.js) en ciblant son origine réelle.
     */
    postToParent(message) {
      window.parent?.postMessage(message, this._parentOrigin || '*');
    },

    /**
     * Envoie un message au service worker background via chrome.runtime.
     */
    async send(action, payload = {}) {
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action, payload }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && !response.success && response.error) {
            reject(new Error(response.error));
          } else {
            resolve(response);
          }
        });
      });
    },

    /**
     * Formate une date ISO en texte lisible.
     */
    formatDate(isoString) {
      try {
        const d = new Date(isoString);
        const now = new Date();
        const diff = (now - d) / 1000; // secondes

        if (diff < 60)       return 'À l\'instant';
        if (diff < 3600)     return `Il y a ${Math.floor(diff / 60)} min`;
        if (diff < 86400)    return `Il y a ${Math.floor(diff / 3600)} h`;
        if (diff < 604800)   return `Il y a ${Math.floor(diff / 86400)} j`;
        return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
      } catch {
        return '';
      }
    },

    /**
     * Copie du texte dans le presse-papier.
     */
    async copyText(text) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity  = '0';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return ok;
      }
    },

    /**
     * Render Markdown minimal → HTML sécurisé.
     */
    renderMarkdown(text) {
      return text
        // Titres H1/H2
        .replace(/^#{1,2}\s+(.+)$/gm, '<strong>$1</strong>')
        // Gras
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        // Italique
        .replace(/_(.+?)_/g, '<em>$1</em>')
        // Retours à la ligne
        .replace(/\n{2,}/g, '\n\n');
    },

    /**
     * Échappe le HTML (sécurité).
     */
    escapeHtml(str) {
      return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     TOAST
  ═══════════════════════════════════════════════════════════════════════════ */
  const Toast = {
    _el: null,
    _timer: null,

    _create() {
      if (this._el) return;
      this._el = document.createElement('div');
      this._el.className = 'toast';
      this._el.setAttribute('role', 'status');
      this._el.setAttribute('aria-live', 'polite');
      document.body.appendChild(this._el);
    },

    show(msg, type = 'default', duration = 2200) {
      this._create();
      this._el.textContent = msg;
      this._el.className   = `toast ${type}`;
      // Force reflow
      void this._el.offsetWidth;
      this._el.classList.add('show');

      clearTimeout(this._timer);
      this._timer = setTimeout(() => {
        this._el.classList.remove('show');
      }, duration);
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     TAB MANAGER
  ═══════════════════════════════════════════════════════════════════════════ */
  const TabManager = {
    init() {
      document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => this.switchTo(tab.dataset.tab));
      });
    },

    switchTo(tabId) {
      // Désactiver tous les onglets et vues
      document.querySelectorAll('.tab').forEach(t => {
        const active = t.dataset.tab === tabId;
        t.classList.toggle('active', active);
        t.setAttribute('aria-selected', active);
      });

      document.querySelectorAll('.view').forEach(v => {
        const active = v.id === `view-${tabId}`;
        v.classList.toggle('active', active);
        v.hidden = !active;
      });

      if (tabId === 'history') History.render();
      if (tabId === 'stats')   Stats.refresh();
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     GENERATOR
  ═══════════════════════════════════════════════════════════════════════════ */
  const Generator = {
    _state: 'idle', // idle | loading | done | error
    _lastPrompt: '',
    _lastResult: '',

    // Étapes affichées dans la barre de progression
    _steps: [
      { id: 'init',    label: 'Initialisation' },
      { id: 'prompt',  label: 'Envoi du prompt' },
      { id: 'ai',      label: 'Génération IA en cours…' },
      { id: 'format',  label: 'Mise en forme' },
      { id: 'save',    label: 'Sauvegarde' },
    ],

    init() {
      // Référence les éléments DOM
      this.promptInput   = document.getElementById('prompt-input');
      this.charCount     = document.getElementById('char-count');
      this.btnGenerate   = document.getElementById('btn-generate');
      this.progressSec   = document.getElementById('progress-section');
      this.progressLabel = document.getElementById('progress-label');
      this.progressPct   = document.getElementById('progress-pct');
      this.progressBar   = document.getElementById('progress-bar');
      this.progressTrack = document.getElementById('progress-track');
      this.progressSteps = document.getElementById('progress-steps');
      this.resultSec     = document.getElementById('result-section');
      this.resultBody    = document.getElementById('result-body');
      this.errorSec      = document.getElementById('error-section');
      this.errorMsg      = document.getElementById('error-msg');
      this.btnCopy       = document.getElementById('btn-copy');
      this.btnNew        = document.getElementById('btn-new');
      this.btnRetry      = document.getElementById('btn-retry');
      this.attachBtn     = document.getElementById('attach-btn');
      this.attachInput   = document.getElementById('attach-input');
      this.attachList    = document.getElementById('attachments-list');
      this._attachments  = [];

      this._bindEvents();
      this._renderModules();
      this._renderTemplates();
      this._renderSuggestions();
    },

    _bindEvents() {
      // Compteur de caractères
      this.promptInput.addEventListener('input', () => {
        const len  = this.promptInput.value.length;
        const max  = parseInt(this.promptInput.getAttribute('maxlength'), 10);
        this.charCount.textContent = `${len} / ${max}`;
        this.charCount.classList.toggle('warn',  len > max * 0.8);
        this.charCount.classList.toggle('limit', len >= max);

        // Active / désactive le bouton
        this.btnGenerate.disabled = len < 10;
      });

      // Raccourci Ctrl+Enter / Cmd+Enter pour générer
      this.promptInput.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
          e.preventDefault();
          if (!this.btnGenerate.disabled) this._generate();
        }
      });

      this.btnGenerate.addEventListener('click', () => this._generate());
      this.btnCopy.addEventListener('click',     () => this._copyResult());
      this.btnNew.addEventListener('click',      () => this._reset());
      this.btnRetry.addEventListener('click',    () => this._generate());

      // Pièces jointes (images)
      this.attachBtn?.addEventListener('click', () => this.attachInput.click());
      this.attachInput?.addEventListener('change', (e) => this._addAttachments(e.target.files));

      // Glisser-déposer d'images directement sur la zone de prompt
      const dropZone = this.promptInput?.closest('.textarea-wrapper');
      if (dropZone) {
        ['dragenter', 'dragover'].forEach(ev => dropZone.addEventListener(ev, (e) => {
          if (!e.dataTransfer?.types?.includes('Files')) return;
          e.preventDefault();
          dropZone.classList.add('dragover');
        }));
        ['dragleave', 'drop'].forEach(ev => dropZone.addEventListener(ev, (e) => {
          if (ev === 'drop') {
            e.preventDefault();
            if (e.dataTransfer?.files?.length) this._addAttachments(e.dataTransfer.files);
          }
          dropZone.classList.remove('dragover');
        }));
      }
    },

    async _addAttachments(fileList) {
      const MAX_SIZE = 5 * 1024 * 1024; // 5 Mo par image
      const files = Array.from(fileList || []).filter(f => f.type.startsWith('image/'));
      const room  = 4 - this._attachments.length;
      let skipped = 0;
      for (const file of files.slice(0, room)) {
        if (file.size > MAX_SIZE) { skipped++; continue; }
        // onerror/onabort évitent qu'un fichier illisible bloque la génération à l'infini
        const dataUrl = await new Promise(resolve => {
          const reader = new FileReader();
          reader.onload  = () => resolve(reader.result);
          reader.onerror = () => resolve(null);
          reader.onabort = () => resolve(null);
          try { reader.readAsDataURL(file); } catch { resolve(null); }
        });
        if (dataUrl) this._attachments.push({ name: file.name, dataUrl });
        else skipped++;
      }
      this.attachInput.value = '';
      this._renderAttachments();
      if (skipped > 0 && typeof Toast !== 'undefined')
        Toast.show(`${skipped} image(s) ignorée(s) (illisible ou trop lourde, max 5 Mo).`, 'error');
    },

    _removeAttachment(idx) {
      this._attachments.splice(idx, 1);
      this._renderAttachments();
    },

    _renderAttachments() {
      this.attachList.hidden = this._attachments.length === 0;
      this.attachList.innerHTML = this._attachments.map((a, i) => `
        <div class="attachment-chip">
          <img src="${a.dataUrl}" alt="${Utils.escapeHtml(a.name)}"/>
          <button type="button" class="attachment-chip__remove" data-idx="${i}" aria-label="Retirer">✕</button>
        </div>
      `).join('');
      this.attachList.querySelectorAll('.attachment-chip__remove').forEach(btn => {
        btn.addEventListener('click', () => this._removeAttachment(parseInt(btn.dataset.idx, 10)));
      });
    },

    _renderModules() {
      const grid = document.getElementById('modules-grid');
      if (!grid) return;

      grid.innerHTML = AVAILABLE_MODULES.map(mod => `
        <button class="module-chip ${mod.active ? 'active' : ''}"
                data-module="${mod.id}"
                aria-pressed="${mod.active}"
                title="${mod.label}">
          ${mod.icon}
          <span>${mod.label}</span>
          <span class="module-chip__dot"></span>
        </button>
      `).join('');

      // Toggle modules
      grid.querySelectorAll('.module-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          const mod = AVAILABLE_MODULES.find(m => m.id === chip.dataset.module);
          if (mod) {
            mod.active = !mod.active;
            chip.classList.toggle('active', mod.active);
            chip.setAttribute('aria-pressed', mod.active);
          }
        });
      });
    },

    _renderTemplates() {
      const list = document.getElementById('templates-list');
      if (!list) return;
      list.innerHTML = TEMPLATES.map(t => `
        <button class="template-chip" data-text="${Utils.escapeHtml(t.text)}" title="${t.label}">
          ${t.emoji} ${t.label}
        </button>
      `).join('');
      list.querySelectorAll('.template-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          const isActive = chip.classList.contains('active');
          chip.classList.toggle('active', !isActive);
          // Reconstruit le prompt avec tous les templates actifs
          const selected = [...list.querySelectorAll('.template-chip.active')];
          if (selected.length === 0) {
            this.promptInput.value = '';
          } else if (selected.length === 1) {
            this.promptInput.value = selected[0].dataset.text;
          } else {
            this.promptInput.value = selected.map(c => c.dataset.text).join(' + ');
          }
          this.promptInput.dispatchEvent(new Event('input'));
          this.promptInput.focus();
        });
      });
    },

    _renderSuggestions() {
      const list = document.getElementById('suggestions-list');
      if (!list) return;
      list.innerHTML = SUGGESTIONS.map(s => `
        <button class="suggestion-chip" data-niche="${s.replace(/^[^\s]+\s/, '').trim()}">${s}</button>
      `).join('');
      list.querySelectorAll('.suggestion-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          const isActive = chip.classList.contains('active');
          // Toggle l'état actif
          chip.classList.toggle('active', !isActive);
          const niche = chip.dataset.niche;
          const current = this.promptInput.value;
          if (!isActive) {
            // Ajout de la niche
            if (current.length === 0) {
              this.promptInput.value = `Crée une vidéo TikTok virale sur le thème ${niche}, 30 secondes, ton engageant.`;
            } else {
              this.promptInput.value = current + ` [Niche : ${niche}]`;
            }
          } else {
            // Retrait de la niche
            this.promptInput.value = current.replace(` [Niche : ${niche}]`, '').replace(`Crée une vidéo TikTok virale sur le thème ${niche}, 30 secondes, ton engageant.`, '').trim();
          }
          this.promptInput.dispatchEvent(new Event('input'));
          this.promptInput.focus();
        });
      });
    },

    async _generate() {
      const prompt = this.promptInput.value.trim();
      if (prompt.length < 10) return;

      this._lastPrompt = prompt;
      this._setState('loading');

      try {
        // Simulation de progression (l'API OpenAI ne streame pas ici,
        // donc on anime de façon réaliste pendant l'attente)
        const progressPromise = this._animateProgress();

        const activeSteps = AVAILABLE_MODULES
          .filter(m => m.active)
          .map(({ id, instruction }) => ({ id, instruction }));

        const result = await Utils.send('GENERATE_CONTENT', {
          prompt,
          steps: activeSteps,
          images: this._attachments.map(a => a.dataUrl),
        });

        // On arrête l'animation et on passe à 100%
        clearInterval(this._progressInterval);
        this._setProgress(100, 'Finalisation…');
        this._markStepDone(this._steps.length - 1);

        await new Promise(r => setTimeout(r, 400));

        this._lastResult = result.content;
        VideoGen.setPrompt(this._lastPrompt);
        VideoGen.setContent(result.content);
        VideoGen.setImages(this._attachments.map(a => a.dataUrl));
        VideoGen.reset();
        this._setState('done');

      } catch (err) {
        clearInterval(this._progressInterval);
        this._lastError = err.message;
        this._setState('error');
      }
    },

    /**
     * Anime la barre de progression de façon réaliste.
     * Avance vite au début, ralentit avant 95% pour attendre la réponse IA.
     */
    _animateProgress() {
      let current = 0;
      let stepIdx = 0;

      // Afficher la section progression
      this.progressSec.hidden  = false;
      this.resultSec.hidden    = true;
      this.errorSec.hidden     = true;

      // Affiche toutes les étapes
      this.progressSteps.innerHTML = this._steps.map((s, i) => `
        <div class="progress-step" id="pstep-${i}">
          <svg class="progress-step__icon" viewBox="0 0 12 12" fill="none">
            <circle cx="6" cy="6" r="5" stroke="currentColor" stroke-width="1.5"/>
          </svg>
          ${s.label}
        </div>
      `).join('');

      this._markStepActive(0);

      // Cibles de progression par étape
      const targets = [5, 15, 85, 95, 99];

      this._progressInterval = setInterval(() => {
        if (stepIdx < targets.length && current >= targets[stepIdx]) {
          stepIdx++;
          if (stepIdx < this._steps.length) {
            this._markStepDone(stepIdx - 1);
            this._markStepActive(stepIdx);
          }
        }

        // Ralentissement exponentiel avant 95%
        const speed = current < 85 ? 1.5 : 0.2;
        if (current < 99) {
          current = Math.min(current + speed, 99);
          this._setProgress(current, this._steps[stepIdx]?.label || 'En cours…');
        }
      }, 80);
    },

    _setProgress(pct, label) {
      const rounded = Math.round(pct);
      this.progressBar.style.width    = `${pct}%`;
      this.progressTrack.setAttribute('aria-valuenow', rounded);
      this.progressPct.textContent    = `${rounded}%`;
      if (label) this.progressLabel.textContent = label;
    },

    _markStepActive(idx) {
      const el = document.getElementById(`pstep-${idx}`);
      if (el) el.classList.add('active');
    },

    _markStepDone(idx) {
      const el = document.getElementById(`pstep-${idx}`);
      if (!el) return;
      el.classList.remove('active');
      el.classList.add('done');
      el.querySelector('svg').innerHTML =
        '<path stroke="currentColor" stroke-width="1.5" stroke-linecap="round" ' +
        'stroke-linejoin="round" d="M2.5 6l2.5 2.5 4.5-4.5"/>'; // ✓
    },

    _setState(state) {
      this._state = state;
      const btn   = this.btnGenerate;

      switch (state) {
        case 'idle':
          btn.classList.remove('loading');
          btn.disabled = this.promptInput.value.trim().length < 10;
          this.progressSec.hidden = true;
          this.resultSec.hidden   = true;
          this.errorSec.hidden    = true;
          break;

        case 'loading':
          btn.classList.add('loading');
          btn.disabled = true;
          this.progressSec.hidden = false;
          this.resultSec.hidden   = true;
          this.errorSec.hidden    = true;
          break;

        case 'done':
          btn.classList.remove('loading');
          btn.disabled = false;
          this.progressSec.hidden = true;
          this.resultSec.hidden   = false;
          this.errorSec.hidden    = true;

          // Affiche le résultat en cartes par section (fallback : rendu simple)
          this._renderResult(this._lastResult);

          // Met à jour le badge histoire
          History.refresh();
          break;

        case 'error':
          btn.classList.remove('loading');
          btn.disabled = false;
          this.progressSec.hidden = true;
          this.resultSec.hidden   = true;
          this.errorSec.hidden    = false;
          this.errorMsg.textContent = this._lastError || 'Erreur inconnue.';
          break;
      }
    },

    async _copyResult() {
      if (!this._lastResult) return;
      const ok = await Utils.copyText(this._lastResult);
      Toast.show(ok ? 'Copié dans le presse-papier' : 'Échec de la copie', ok ? 'success' : 'error');
    },

    /**
     * Rendu du résultat en cartes par section numérotée (1. …, 2. …),
     * avec bouton copier individuel et hashtags mis en valeur.
     * Fallback : rendu simple si la structure n'est pas détectée.
     */
    _renderResult(text) {
      const lines = (text || '').split('\n');

      // Détecte les en-têtes de section : "1. TITRE", "**2) Titre**", "## 3. Titre"…
      const headerOf = (line) => {
        const t = line.trim().replace(/^#{1,3}\s*/, '').replace(/^\*\*|\*\*:?\s*$/g, '').trim();
        if (!t || t.length > 90) return null;
        return /^\d{1,2}\s*[\.\)]\s+\S/.test(t) ? t : null;
      };

      const sections = [];
      let cur = { title: null, lines: [] };
      for (const line of lines) {
        const h = headerOf(line);
        if (h) {
          if (cur.title !== null || cur.lines.some(l => l.trim())) sections.push(cur);
          cur = { title: h, lines: [] };
        } else {
          cur.lines.push(line);
        }
      }
      sections.push(cur);

      // Structure non détectée → rendu simple d'origine
      const titled = sections.filter(s => s.title !== null);
      if (titled.length < 2) {
        const safe = Utils.escapeHtml(text);
        this.resultBody.innerHTML = Utils.renderMarkdown(safe).replace(/\n/g, '<br>');
        return;
      }

      const renderBody = (bodyLines) => {
        const html = [];
        let inList = false;
        for (const raw of bodyLines) {
          const line = raw.trim();
          if (!line) { if (inList) { html.push('</ul>'); inList = false; } continue; }
          let safe = Utils.renderMarkdown(Utils.escapeHtml(line));
          // Hashtags en évidence
          safe = safe.replace(/(^|\s)(#[\p{L}0-9_]{2,})/gu, '$1<span class="hashtag">$2</span>');
          const li = line.match(/^[-•*]\s+(.*)/);
          if (li) {
            if (!inList) { html.push('<ul class="result-list">'); inList = true; }
            html.push(`<li>${safe.replace(/^[-•*]\s+/, '')}</li>`);
          } else {
            if (inList) { html.push('</ul>'); inList = false; }
            html.push(`<p>${safe}</p>`);
          }
        }
        if (inList) html.push('</ul>');
        return html.join('');
      };

      this._sectionTexts = [];
      const parts = [];
      for (const s of sections) {
        const bodyText = s.lines.join('\n').trim();
        if (s.title === null) {
          if (bodyText) parts.push(`<div class="result-intro">${renderBody(s.lines)}</div>`);
          continue;
        }
        const idx = this._sectionTexts.length;
        this._sectionTexts.push(`${s.title}\n${bodyText}`);
        const safeTitle = Utils.renderMarkdown(Utils.escapeHtml(s.title.replace(/^\d{1,2}\s*[\.\)]\s*/, '')));
        parts.push(`
          <div class="result-card">
            <div class="result-card__head">
              <span class="result-card__title">${safeTitle}</span>
              <button type="button" class="result-card__copy" data-sec="${idx}" title="Copier cette section" aria-label="Copier cette section">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              </button>
            </div>
            <div class="result-card__body">${renderBody(s.lines)}</div>
          </div>`);
      }
      this.resultBody.innerHTML = parts.join('');

      this.resultBody.querySelectorAll('.result-card__copy').forEach(btn => {
        btn.addEventListener('click', async () => {
          const t = this._sectionTexts[parseInt(btn.dataset.sec, 10)] || '';
          const ok = await Utils.copyText(t);
          Toast.show(ok ? 'Section copiée' : 'Échec de la copie', ok ? 'success' : 'error');
        });
      });
    },

    /**
     * Rouvre une génération passée depuis l'historique :
     * résultat complet en cartes + vidéo régénérable.
     */
    openFromHistory(entry) {
      clearInterval(this._progressInterval);
      this._lastPrompt = entry.prompt || '';
      this._lastResult = entry.result || '';
      this.promptInput.value = this._lastPrompt;
      this.promptInput.dispatchEvent(new Event('input'));
      VideoGen.setPrompt(this._lastPrompt);
      VideoGen.setContent(this._lastResult);
      VideoGen.setImages([]);
      VideoGen.reset();
      this._setState('done');
      TabManager.switchTo('generate');
      this.resultSec?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    },

    _reset() {
      clearInterval(this._progressInterval); // évite un intervalle orphelin qui continue d'écrire la barre
      this.promptInput.value = '';
      this.charCount.textContent = '0 / 2000';
      this._lastPrompt = '';
      this._lastResult = '';
      this._attachments = [];
      this._renderAttachments();
      VideoGen.setImages([]);
      VideoGen.reset();
      this._setState('idle');
      this.promptInput.focus();
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     HISTORY
  ═══════════════════════════════════════════════════════════════════════════ */
  const History = {
    _entries: [],
    _filter: '',

    init() {
      document.getElementById('btn-clear-history')
        .addEventListener('click', () => this._clearAll());
      // Recherche dans l'historique
      const search = document.getElementById('history-search');
      search?.addEventListener('input', () => {
        this._filter = search.value.trim().toLowerCase();
        this._renderList();
      });
      // Export en fichier texte
      document.getElementById('btn-export-history')
        ?.addEventListener('click', () => this._export());
    },

    _export() {
      if (!this._entries.length) {
        Toast.show('Aucune génération à exporter', 'error');
        return;
      }
      const header = `STIDIA — Export de l'historique (${this._entries.length} génération${this._entries.length > 1 ? 's' : ''})\n\n`;
      const body = this._entries.map(e =>
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n${Utils.formatDate(e.createdAt)}\nPROMPT : ${e.prompt || ''}\n\n${e.result || ''}\n`
      ).join('\n');
      const blob = new Blob([header + body], { type: 'text/plain;charset=utf-8' });
      const url  = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'stidia-historique.txt';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      Toast.show('Historique exporté', 'success');
    },

    async refresh() {
      try {
        const res = await Utils.send('GET_HISTORY');
        this._entries = res.history || [];
        this._updateBadge();
      } catch (err) {
        console.warn('[History] refresh error:', err);
      }
    },

    // Entrées visibles selon la recherche (prompt OU contenu du résultat)
    _visible() {
      if (!this._filter) return this._entries;
      const q = this._filter;
      return this._entries.filter(e =>
        (e.prompt || '').toLowerCase().includes(q) ||
        (e.result || '').toLowerCase().includes(q));
    },

    async render() {
      await this.refresh();
      this._renderList();
    },

    _renderList() {
      const list  = document.getElementById('history-list');
      const empty = document.getElementById('history-empty');
      const info  = document.getElementById('history-info');

      const visible = this._visible();
      const n = visible.length;
      info.textContent = this._filter
        ? `${n} résultat${n !== 1 ? 's' : ''}`
        : `${n} génération${n !== 1 ? 's' : ''}`;

      if (n === 0) {
        list.innerHTML = '';
        empty.hidden   = false;
        return;
      }

      empty.hidden   = true;
      list.innerHTML = visible.map(entry => this._renderEntry(entry)).join('');

      // Bind expand / delete pour chaque entrée
      list.querySelectorAll('.history-entry').forEach(el => {
        const id = el.dataset.id;

        el.querySelector('.history-entry__head').addEventListener('click', () => {
          el.classList.toggle('expanded');
        });

        el.querySelector('[data-action="copy"]')?.addEventListener('click', async (e) => {
          e.stopPropagation();
          const entry = this._entries.find(h => h.id === id);
          if (!entry) return;
          const ok = await Utils.copyText(entry.result);
          Toast.show(ok ? 'Copié' : 'Échec', ok ? 'success' : 'error');
        });

        el.querySelector('[data-action="delete"]')?.addEventListener('click', async (e) => {
          e.stopPropagation();
          await this._deleteEntry(id);
          el.remove();
          await this.refresh();
          if (this._entries.length === 0) {
            document.getElementById('history-empty').hidden = false;
          }
        });

        el.querySelector('[data-action="reuse"]')?.addEventListener('click', (e) => {
          e.stopPropagation();
          const entry = this._entries.find(h => h.id === id);
          if (!entry) return;
          TabManager.switchTo('generate');
          Generator.promptInput.value = entry.prompt;
          Generator.promptInput.dispatchEvent(new Event('input'));
          Generator.promptInput.focus();
          Toast.show('Prompt rechargé', 'success');
        });

        el.querySelector('[data-action="open"]')?.addEventListener('click', (e) => {
          e.stopPropagation();
          const entry = this._entries.find(h => h.id === id);
          if (!entry) return;
          Generator.openFromHistory(entry);
          Toast.show('Génération rouverte', 'success');
        });
      });
    },

    _renderEntry(entry) {
      const prompt  = Utils.escapeHtml(entry.prompt || '');
      const result  = Utils.escapeHtml(entry.result || '');
      const date    = Utils.formatDate(entry.createdAt);
      const preview = result.slice(0, 300) + (result.length > 300 ? '…' : '');

      return `
        <div class="history-entry" data-id="${entry.id}">
          <div class="history-entry__head">
            <div class="history-entry__icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
              </svg>
            </div>
            <div class="history-entry__meta">
              <div class="history-entry__prompt" title="${prompt}">${prompt}</div>
              <div class="history-entry__date">${date} · ${entry.model || 'GPT-4o'}</div>
            </div>
            <button class="history-entry__toggle" aria-label="Déplier / Replier">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </button>
          </div>

          <div class="history-entry__body">
            <div class="history-entry__result">${preview.replace(/\n/g, '<br>')}</div>
            <div class="history-entry__footer">
              <button class="chip-btn chip-btn--success" data-action="open">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
                Rouvrir
              </button>
              <button class="chip-btn" data-action="copy">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2"/>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                </svg>
                Copier
              </button>
              <button class="chip-btn" data-action="reuse">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="1 4 1 10 7 10"/>
                  <path d="M3.51 15a9 9 0 1 0 .49-3.37"/>
                </svg>
                Réutiliser
              </button>
              <button class="chip-btn chip-btn--danger" data-action="delete">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="3 6 5 6 21 6"/>
                  <path d="M19 6l-1 14H6L5 6"/>
                </svg>
                Supprimer
              </button>
            </div>
          </div>
        </div>
      `;
    },

    _updateBadge() {
      const n     = this._entries.length;
      const badge = document.getElementById('history-count');
      if (!badge) return;

      if (n > 0) {
        badge.textContent = n > 99 ? '99+' : String(n);
        badge.classList.add('visible');
      } else {
        badge.classList.remove('visible');
      }

      // Met aussi à jour le badge de la bulle flottante dans content.js
      Utils.postToParent({
        source:  'tiktok-ai-sidebar',
        action:  'UPDATE_BADGE',
        payload: { count: n },
      });
    },

    async _deleteEntry(id) {
      try {
        await Utils.send('DELETE_HISTORY_ENTRY', { id });
      } catch (err) {
        console.warn('[History] delete error:', err);
      }
    },

    async _clearAll() {
      if (!confirm('Effacer tout l\'historique ?')) return;
      try {
        await Utils.send('CLEAR_HISTORY');
        this._entries = [];
        this._updateBadge();
        await this.render();
        Toast.show('Historique effacé', 'default');
      } catch (err) {
        Toast.show('Erreur lors de la suppression', 'error');
      }
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     STATS
  ═══════════════════════════════════════════════════════════════════════════ */
  /* ═══════════════════════════════════════════════════════════════════════════
     VIDEO GEN  —  Images IA (Pollinations.ai) + Canvas + MediaRecorder
  ═══════════════════════════════════════════════════════════════════════════ */
  const VideoGen = {
    _prompt:       '',
    _content:      '',
    _images:       [],
    _isGenerating: false,
    _apiKey:       null,
    _blobUrl:      null,

    init() {
      this._btnTrigger  = document.getElementById('btn-capcut');
      this._noKey       = document.getElementById('video-no-key');
      this._loading     = document.getElementById('video-loading');
      this._loadLabel   = document.getElementById('video-loading-label');
      this._result      = document.getElementById('video-result');
      this._player      = document.getElementById('video-player');
      this._download    = document.getElementById('btn-download-video');
      this._error       = document.getElementById('video-error');
      this._errorMsg    = document.getElementById('video-error-msg');
      this._btnSettings = document.getElementById('btn-open-settings-video');
      this._btnRegen    = document.getElementById('btn-regen-video');
      this._btnRetry    = document.getElementById('btn-retry-video');

      this._btnTrigger?.addEventListener('click',  () => this._start());
      this._btnSettings?.addEventListener('click', () => Settings.open());
      this._btnRegen?.addEventListener('click',    () => this._start());
      this._btnRetry?.addEventListener('click',    () => this._start());
    },

    setPrompt(prompt)   { this._prompt  = prompt; },
    setContent(content) { this._content = content; },
    setImages(images)   { this._images  = images || []; },

    _setState(state) {
      this._noKey.hidden      = state !== 'nokey';
      this._loading.hidden    = state !== 'loading';
      this._result.hidden     = state !== 'done';
      this._error.hidden      = state !== 'error';
      this._btnTrigger.hidden = state !== 'idle';
    },

    async _start() {
      if (this._isGenerating) return;

      const keyRes = await Utils.send('GET_VIDEO_KEY').catch(() => null);
      this._apiKey = keyRes?.videoKey?.trim() || null;

      if (!this._apiKey) {
        this._setState('nokey');
        return;
      }

      this._isGenerating = true;
      this._setState('loading');
      this._loadLabel.textContent = 'Recherche de séquences vidéo…';

      try {
        const blob = await this._run();
        if (this._blobUrl) URL.revokeObjectURL(this._blobUrl);
        this._blobUrl = URL.createObjectURL(blob);
        this._showVideo(this._blobUrl);
      } catch (err) {
        this._showError(err.message);
      } finally {
        this._isGenerating = false;
      }
    },

    // ── 1. Mots-clés visuels extraits du script ────────────────────────────────
    _extractKeywords() {
      const stop = new Set(['le','la','les','un','une','des','de','du','et','en','que','qui','dans',
        'est','par','avec','pour','sur','au','aux','mais','plus','très','bien','tout','tous','toutes',
        'être','avoir','faire','sans','dont','sous','aussi','vers','chez','leur','leurs','cette','cette',
        'comme','donc','ou','car','ni','ses','son','sa','ton','ta','tes','mon','ma','mes','nos','notre',
        'votre','vos','ils','elles','nous','vous','tiktok','vidéo','video','contenu','script','hook',
        'accroche','scène','plan','texte','voix','musique','transition','hashtag','timing','conseil'
      ]);
      const text = `${this._prompt} ${this._content}`.toLowerCase()
        .replace(/[^a-zàâäéèêëîïôöùûüçñ\s]/gi, ' ')
        .split(/\s+/)
        .filter(w => w.length > 3 && !stop.has(w));
      const freq = {};
      text.forEach(w => { freq[w] = (freq[w] || 0) + 1; });
      const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([w]) => w);
      return top.length ? top : ['lifestyle', 'energy', 'city', 'motivation'];
    },

    // ── 2. Lignes de texte à afficher en overlay sur chaque clip ───────────────
    _extractLines(count) {
      const lines = this._content
        .split('\n')
        .map(l => l.replace(/\*\*(.*?)\*\*/g, '$1').replace(/^[\-\*•►▶🎬📝🎵🎨⏱️💡#️⃣]+\s*/, '').trim())
        .filter(l => l.length > 15 && l.length < 110
          && !/^#{1,4}/.test(l)
          && !/^(hashtag|timing|conseil|musique)/i.test(l))
        .slice(0, count);
      while (lines.length < count) lines.push(this._prompt || 'Stidia');
      return lines;
    },

    // ── 3. Cherche un clip vertical Pexels pour un mot-clé ──────────────────────
    async _fetchClip(keyword) {
      const res = await fetch(
        `https://api.pexels.com/videos/search?query=${encodeURIComponent(keyword)}&orientation=portrait&size=medium&per_page=3`,
        { headers: { 'Authorization': this._apiKey } }
      );
      if (res.status === 401) throw new Error('Clé Pexels invalide. Vérifie-la dans les paramètres.');
      if (!res.ok) return null;
      const data = await res.json();
      if (!data.videos?.length) return null;
      const vid  = data.videos[Math.floor(Math.random() * data.videos.length)];
      const file = vid.video_files
        .filter(f => f.file_type === 'video/mp4' && f.width && f.width <= 720)
        .sort((a, b) => (b.width * b.height) - (a.width * a.height))[0]
        || vid.video_files.find(f => f.file_type === 'video/mp4');
      return file ? file.link : null;
    },

    // ── 4. Charge un clip dans un <video> caché ─────────────────────────────────
    _loadVideo(url) {
      return new Promise((resolve, reject) => {
        const vid = document.createElement('video');
        vid.crossOrigin = 'anonymous';
        vid.muted   = true;
        vid.preload = 'auto';
        vid.playsInline = true;
        const t = setTimeout(() => reject(new Error('Timeout chargement clip')), 20000);
        vid.oncanplaythrough = () => { clearTimeout(t); resolve(vid); };
        vid.onerror = () => { clearTimeout(t); reject(new Error('Erreur chargement clip')); };
        vid.src = url;
        vid.load();
      });
    },

    // ── Charge une image jointe par l'utilisateur ───────────────────────────────
    _loadImage(dataUrl) {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload  = () => resolve(img);
        img.onerror = () => reject(new Error('Erreur chargement image jointe'));
        img.src = dataUrl;
      });
    },

    // ── 5. Pipeline complet ──────────────────────────────────────────────────
    async _run() {
      const scenes = [];

      // Photos jointes par l'utilisateur en priorité : elles apparaissent dans la vidéo.
      if (this._images.length) {
        this._loadLabel.textContent = 'Intégration de tes photos…';
        for (const dataUrl of this._images) {
          try { scenes.push({ type: 'image', el: await this._loadImage(dataUrl) }); } catch {}
        }
      }

      const keywords = this._extractKeywords();
      this._loadLabel.textContent = `Recherche de clips… (${keywords.join(', ')})`;

      const urls = [];
      for (const kw of keywords) {
        const url = await this._fetchClip(kw);
        if (url) urls.push(url);
      }
      if (!urls.length && !scenes.length) throw new Error('Aucun clip trouvé sur Pexels pour ce script. Réessaie.');

      this._loadLabel.textContent = 'Chargement des séquences vidéo…';
      for (const url of urls) {
        try { scenes.push({ type: 'video', el: await this._loadVideo(url) }); } catch {}
      }
      if (!scenes.length) throw new Error('Impossible de charger les clips (réseau). Réessaie.');

      const lines = this._extractLines(scenes.length);
      return await this._record(scenes, lines);
    },

    // ── 6. Assemble les clips/photos sur un canvas et enregistre ────────────────
    async _record(scenes, lines) {
      // Garde : message clair si le navigateur ne supporte pas la capture vidéo
      if (typeof MediaRecorder === 'undefined' ||
          !document.createElement('canvas').captureStream) {
        throw new Error("La génération vidéo n'est pas supportée par ce navigateur. Essaie Chrome ou Edge à jour.");
      }

      const W = 540, H = 960, FPS = 30, CLIP_SEC = 5;
      const clipFrames  = FPS * CLIP_SEC;
      const totalFrames = scenes.length * clipFrames;

      const canvas = document.createElement('canvas');
      canvas.width = W; canvas.height = H;
      const ctx    = canvas.getContext('2d');
      const videoStream = canvas.captureStream(FPS);

      // ── Capture le son des clips vidéo (les photos n'ont pas de son) ──────────
      let audioTracks = [];
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          // Sans reprise explicite, le contexte reste 'suspended' et n'enregistre rien
          if (audioCtx.state === 'suspended') { try { await audioCtx.resume(); } catch {} }
          const dest = audioCtx.createMediaStreamDestination();
          let connected = 0;
          scenes.filter(s => s.type === 'video').forEach(s => {
            try {
              const src = audioCtx.createMediaElementSource(s.el);
              src.connect(dest);
              // Routé vers le graphe (→ enregistrement), donc on démute : l'audio
              // n'est plus muet dans le fichier final, sans passer par les haut-parleurs.
              s.el.muted = false;
              connected++;
            } catch {}
          });
          if (connected > 0) audioTracks = dest.stream.getAudioTracks();
        }
      } catch {}

      const stream = new MediaStream([...videoStream.getVideoTracks(), ...audioTracks]);
      const mime   = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
        .find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';
      const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 5000000 });
      const chunks    = [];
      recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };

      return new Promise((resolve, reject) => {
        recorder.onstop  = () => resolve(new Blob(chunks, { type: 'video/webm' }));
        recorder.onerror = e  => reject(new Error('Enregistrement: ' + (e.error?.message || 'erreur')));
        recorder.start(100);

        let ci = 0, frame = 0;

        const nextScene = () => {
          if (ci >= scenes.length) { recorder.stop(); return; }
          const scene = scenes[ci];

          if (scene.type === 'image') {
            let cf = 0;
            const tick = () => {
              if (cf >= clipFrames) {
                ci++; frame += cf;
                this._loadLabel.textContent = `Assemblage… ${Math.round((frame / totalFrames) * 100)}%`;
                nextScene();
                return;
              }
              this._drawFrame(ctx, W, H, scene.el, lines[ci], cf / clipFrames, true);
              cf++;
              setTimeout(tick, 1000 / FPS);
            };
            tick();
            return;
          }

          const vid = scene.el;
          vid.currentTime = 0;

          vid.play().then(() => {
            let cf = 0;
            const tick = () => {
              if (cf >= clipFrames || vid.ended) {
                vid.pause();
                ci++; frame += cf;
                this._loadLabel.textContent = `Assemblage… ${Math.round((frame / totalFrames) * 100)}%`;
                nextScene();
                return;
              }
              try {
                this._drawFrame(ctx, W, H, vid, lines[ci], cf / clipFrames, false);
              } catch (e) {
                recorder.stop();
                reject(new Error('Lecture vidéo bloquée (CORS). Réessaie ou change de script.'));
                return;
              }
              cf++;
              setTimeout(tick, 1000 / FPS);
            };
            tick();
          }).catch(() => { ci++; nextScene(); });
        };

        nextScene();
      });
    },

    _drawFrame(ctx, W, H, media, text, progress, isImage) {
      const vw = media.videoWidth  || media.naturalWidth  || 1280;
      const vh = media.videoHeight || media.naturalHeight || 720;
      const zoom  = isImage ? 1 + progress * 0.08 : 1; // léger Ken Burns sur les photos jointes
      const scale = Math.max(W / vw, H / vh) * zoom;
      const dw = vw * scale, dh = vh * scale;
      ctx.drawImage(media, (W - dw) / 2, (H - dh) / 2, dw, dh);

      const ov = ctx.createLinearGradient(0, H * 0.55, 0, H);
      ov.addColorStop(0, 'rgba(0,0,0,0)');
      ov.addColorStop(1, 'rgba(0,0,0,0.82)');
      ctx.fillStyle = ov;
      ctx.fillRect(0, 0, W, H);

      const fade = progress < 0.06 ? progress / 0.06 : progress > 0.92 ? (1 - progress) / 0.08 : 1;
      ctx.globalAlpha = fade;

      ctx.textAlign   = 'center';
      ctx.shadowColor = 'rgba(0,0,0,1)';
      ctx.shadowBlur  = 18;
      ctx.font        = 'bold 28px Arial, sans-serif';
      ctx.fillStyle   = '#fff';
      this._wrap(ctx, text, W / 2, H * 0.87, W - 48, 36);

      ctx.globalAlpha = 1;
      ctx.shadowBlur  = 0;
    },

    _wrap(ctx, text, x, y, maxW, lh) {
      const words = String(text).split(' ');
      let line = '', lines = [];
      for (const w of words) {
        const t = line + w + ' ';
        if (ctx.measureText(t).width > maxW && line) { lines.push(line.trim()); line = w + ' '; }
        else line = t;
      }
      if (line.trim()) lines.push(line.trim());
      const sy = y - ((lines.length - 1) * lh) / 2;
      lines.forEach((l, i) => ctx.fillText(l, x, sy + i * lh));
    },

    _showVideo(url) {
      this._player.src    = url;
      this._player.onpause = null;
      this._player.onseeking = null;
      this._player.ontimeupdate = null;
      this._player.setAttribute('controls', '');
      this._download.href = url;
      this._download.setAttribute('download', 'stidia.webm');
      this._setState('done');
      this._player.play().catch(() => {});
    },

    _showError(msg) {
      this._errorMsg.textContent = msg || 'Erreur de génération.';
      this._setState('error');
    },

    reset() {
      this._isGenerating = false;
      if (this._blobUrl) { URL.revokeObjectURL(this._blobUrl); this._blobUrl = null; }
      this._setState('idle');
      this._player.src = '';
    },
  };

  const Stats = {
    init() {
      this._container = document.getElementById('stats-content');
    },

    async refresh() {
      if (!this._container) return;
      try {
        const res = await Utils.send('GET_HISTORY');
        this._render(res.history || []);
      } catch {
        this._render([]);
      }
    },

    _render(history) {
      const now    = new Date();
      const today  = now.toISOString().slice(0, 10);
      const weekMs = 7 * 86400000;

      const total    = history.length;
      const todayCnt = history.filter(e => e.createdAt?.slice(0, 10) === today).length;
      const weekCnt  = history.filter(e => new Date(e.createdAt) >= new Date(now - weekMs)).length;

      const avgLen = total
        ? Math.round(history.reduce((s, e) => s + (e.result?.length || 0), 0) / total)
        : 0;

      // Données 14 derniers jours
      const days = [];
      for (let i = 13; i >= 0; i--) {
        const d   = new Date(now - i * 86400000);
        const str = d.toISOString().slice(0, 10);
        days.push({
          label: d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
          count: history.filter(e => e.createdAt?.slice(0, 10) === str).length,
        });
      }

      // Top sujets détectés dans les prompts
      const topicMap = {
        'Fitness':  ['fitness','sport','gym','muscul','entraîn'],
        'Food':     ['food','recette','cuisine','manger','resto'],
        'Voyage':   ['voyage','travel','pays','destination'],
        'Gaming':   ['gaming','jeu','game','stream','esport'],
        'Beauté':   ['beauté','makeup','cosmé','soin'],
        'Tech / IA':['tech','ia','intelligence','gadget','vidéo ia'],
        'Finance':  ['finance','argent','invest','crypto','trading'],
        'Humour':   ['humour','funny','drôle','sketch','coméd'],
        'Mode':     ['mode','style','outfit','vêtement','fashion'],
        'Animaux':  ['chat','chien','animal','pet','nimal'],
      };
      const topicCounts = {};
      Object.keys(topicMap).forEach(k => { topicCounts[k] = 0; });
      history.forEach(e => {
        const txt = ((e.prompt || '') + ' ' + (e.result || '')).toLowerCase();
        Object.entries(topicMap).forEach(([k, kws]) => {
          if (kws.some(kw => txt.includes(kw))) topicCounts[k]++;
        });
      });
      const topTopics = Object.entries(topicCounts)
        .filter(([, c]) => c > 0)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 6);

      this._container.innerHTML = `
        <!-- Cartes résumé -->
        <div class="stats-cards">
          <div class="stats-card">
            <span class="stats-card__val">${total}</span>
            <span class="stats-card__lbl">Total</span>
          </div>
          <div class="stats-card stats-card--accent">
            <span class="stats-card__val">${weekCnt}</span>
            <span class="stats-card__lbl">Cette semaine</span>
          </div>
          <div class="stats-card">
            <span class="stats-card__val">${todayCnt}</span>
            <span class="stats-card__lbl">Aujourd'hui</span>
          </div>
          <div class="stats-card">
            <span class="stats-card__val">${avgLen > 0 ? (avgLen > 999 ? Math.round(avgLen/1000) + 'k' : avgLen) : '—'}</span>
            <span class="stats-card__lbl">Moy. caractères</span>
          </div>
        </div>

        <!-- Graphique activité -->
        <div class="stats-section">
          <h3 class="stats-section__title">Activité — 14 derniers jours</h3>
          <div class="stats-chart" id="chart-activity"></div>
        </div>

        ${topTopics.length > 0 ? `
        <!-- Graphique sujets -->
        <div class="stats-section">
          <h3 class="stats-section__title">Sujets les plus générés</h3>
          <div class="stats-bars" id="chart-topics"></div>
        </div>` : ''}

        ${total === 0 ? `
        <div class="stats-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
          </svg>
          <p>Génère du contenu pour voir tes statistiques ici.</p>
        </div>` : ''}
      `;

      this._drawLine(days);
      if (topTopics.length > 0) this._drawBars(topTopics);
    },

    _drawLine(days) {
      const wrap = document.getElementById('chart-activity');
      if (!wrap) return;
      const W = 370, H = 130;
      const pL = 28, pR = 12, pT = 12, pB = 32;
      const cW = W - pL - pR, cH = H - pT - pB;
      const max = Math.max(...days.map(d => d.count), 1);

      const pts = days.map((d, i) => ({
        x: pL + (i / (days.length - 1)) * cW,
        y: pT + cH - (d.count / max) * cH,
        ...d,
      }));

      const linePath = pts.map((p, i) =>
        `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`
      ).join(' ');

      const areaPath = linePath
        + ` L${pts[pts.length - 1].x.toFixed(1)},${(pT + cH).toFixed(1)}`
        + ` L${pts[0].x.toFixed(1)},${(pT + cH).toFixed(1)} Z`;

      const gridLines = [0, 1, 2, 3].map(i => {
        const y   = pT + (i / 3) * cH;
        const val = Math.round(max - (i / 3) * max);
        return `<line x1="${pL}" y1="${y.toFixed(1)}" x2="${W - pR}" y2="${y.toFixed(1)}"
                      stroke="rgba(255,255,255,0.06)" stroke-width="1"/>
                <text x="${pL - 4}" y="${(y + 3.5).toFixed(1)}" text-anchor="end"
                      fill="rgba(255,255,255,0.3)" font-size="8">${val}</text>`;
      }).join('');

      const labels = pts.map((p, i) =>
        i % 2 === 0
          ? `<text x="${p.x.toFixed(1)}" y="${H - 4}" text-anchor="middle"
                   fill="rgba(255,255,255,0.3)" font-size="8">${p.label}</text>`
          : ''
      ).join('');

      const circles = pts.map(p =>
        p.count > 0
          ? `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3"
                     fill="#A855F7" stroke="#fff" stroke-width="1.5"/>`
          : ''
      ).join('');

      wrap.innerHTML = `
        <svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:${H}px">
          <defs>
            <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%"   stop-color="#7C3AED" stop-opacity="0.35"/>
              <stop offset="100%" stop-color="#7C3AED" stop-opacity="0"/>
            </linearGradient>
          </defs>
          ${gridLines}
          <path d="${areaPath}" fill="url(#areaGrad)"/>
          <path d="${linePath}" fill="none" stroke="#7C3AED" stroke-width="2"
                stroke-linecap="round" stroke-linejoin="round"/>
          ${circles}
          ${labels}
        </svg>`;
    },

    _drawBars(topics) {
      const wrap = document.getElementById('chart-topics');
      if (!wrap) return;
      const maxVal = topics[0][1];
      const colors = ['#7C3AED','#A855F7','#EC4899','#8B5CF6','#6366F1','#D946EF'];

      wrap.innerHTML = topics.map(([label, count], i) => {
        const pct = Math.round((count / maxVal) * 100);
        return `
          <div class="stats-bar-row">
            <span class="stats-bar-label">${label}</span>
            <div class="stats-bar-track">
              <div class="stats-bar-fill" style="width:${pct}%;background:${colors[i % colors.length]}"></div>
            </div>
            <span class="stats-bar-val">${count}</span>
          </div>`;
      }).join('');
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     SETTINGS
  ═══════════════════════════════════════════════════════════════════════════ */
  const Settings = {
    _current: null,

    init() {
      this.drawer     = document.getElementById('settings-drawer');
      this.overlay    = document.getElementById('settings-overlay');
      this.inputKey   = document.getElementById('api-key');
      this.selectModel = document.getElementById('ai-model');
      this.selectLang  = document.getElementById('language');
      this.rangeHist   = document.getElementById('max-history');
      this.rangeVal    = document.getElementById('max-history-value');
      this.btnToggle   = document.getElementById('btn-toggle-key');
      this.btnSave     = document.getElementById('btn-settings-save');
      this.btnCancel   = document.getElementById('btn-settings-cancel');
      this.btnClose    = document.getElementById('btn-settings-close');

      document.getElementById('btn-settings')
        .addEventListener('click', () => this.open());

      this.overlay.addEventListener('click',  () => this.close());
      this.btnClose.addEventListener('click', () => this.close());
      this.btnCancel.addEventListener('click',() => this.close());
      this.btnSave.addEventListener('click',  () => this.save());

      // Afficher / masquer la clé API
      this.btnToggle.addEventListener('click', () => {
        const isPass = this.inputKey.type === 'password';
        this.inputKey.type = isPass ? 'text' : 'password';
        this.btnToggle.querySelector('svg').innerHTML = isPass
          ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
             <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
             <line x1="1" y1="1" x2="23" y2="23"/>`
          : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
             <circle cx="12" cy="12" r="3"/>`;
      });

      // Mise à jour live de la valeur du range
      this.rangeHist.addEventListener('input', () => {
        this.rangeVal.textContent = this.rangeHist.value;
      });

      // Boutons "Tester" : vérifie les clés en direct auprès des API
      this._wireKeyTest('btn-test-groq', 'api-key', 'hint-groq', async (key) => {
        const r = await fetch('https://api.groq.com/openai/v1/models', {
          headers: { 'Authorization': `Bearer ${key}` },
        });
        return r.ok;
      });
      this._wireKeyTest('btn-test-pexels', 'fal-key', 'hint-pexels', async (key) => {
        const r = await fetch('https://api.pexels.com/videos/search?query=nature&per_page=1', {
          headers: { 'Authorization': key },
        });
        return r.ok;
      });

      this.load();
    },

    async load() {
      try {
        this._current = await Utils.send('GET_SETTINGS');
        this._populate();
      } catch (err) {
        console.warn('[Settings] load error:', err);
      }
    },

    async _populate() {
      if (!this._current) return;
      this.inputKey.value       = this._current.apiKey    || '';
      this.selectModel.value    = this._current.model     || 'llama-3.3-70b-versatile';
      this.selectLang.value     = this._current.language  || 'fr';
      this.rangeHist.value      = this._current.maxHistory || 20;
      this.rangeVal.textContent = this._current.maxHistory || 20;
      // Clé Pexels (vidéo)
      const hfInput = document.getElementById('fal-key');
      if (hfInput) {
        const keyRes = await Utils.send('GET_VIDEO_KEY').catch(() => null);
        hfInput.value = keyRes?.videoKey || '';
      }
    },

    /**
     * Câble un bouton "Tester" : vérifie la clé auprès de l'API réelle
     * et affiche le verdict sous le champ.
     */
    _wireKeyTest(btnId, inputId, hintId, check) {
      const btn   = document.getElementById(btnId);
      const input = document.getElementById(inputId);
      const hint  = document.getElementById(hintId);
      if (!btn || !input) return;
      btn.addEventListener('click', async () => {
        const key = input.value.trim();
        if (!key) {
          if (hint) { hint.textContent = 'Renseigne une clé d\'abord.'; hint.className = 'key-status key-status--bad'; }
          return;
        }
        btn.disabled = true;
        const oldLabel = btn.textContent;
        btn.textContent = '…';
        if (hint) { hint.textContent = 'Vérification…'; hint.className = 'key-status'; }
        let ok = false;
        try { ok = await check(key); } catch { ok = false; }
        btn.disabled = false;
        btn.textContent = oldLabel;
        if (hint) {
          hint.textContent = ok ? '✓ Clé valide, tout est prêt !' : '✗ Clé invalide (ou réseau indisponible)';
          hint.className = 'key-status ' + (ok ? 'key-status--ok' : 'key-status--bad');
        }
      });
    },

    open() {
      this.drawer.hidden = false;
      this.drawer.setAttribute('aria-hidden', 'false');
      this._populate();
      // Focus sur la clé API si elle est vide
      if (!this.inputKey.value) {
        setTimeout(() => this.inputKey.focus(), 50);
      }
    },

    close() {
      if (this.drawer.contains(document.activeElement)) {
        document.activeElement.blur();
      }
      this.drawer.hidden = true;
      this.drawer.setAttribute('aria-hidden', 'true');
    },

    async save() {
      const newSettings = {
        apiKey:     this.inputKey.value.trim(),
        model:      this.selectModel.value,
        language:   this.selectLang.value,
        maxHistory: parseInt(this.rangeHist.value, 10),
      };

      try {
        await Utils.send('SAVE_SETTINGS', newSettings);
        this._current = { ...this._current, ...newSettings };
        // Sauvegarde clé HuggingFace
        const hfKey = document.getElementById('fal-key')?.value.trim();
        if (hfKey !== undefined) {
          await Utils.send('SAVE_VIDEO_KEY', { videoKey: hfKey }).catch(() => {});
        }
        Toast.show('Paramètres enregistrés', 'success');
        this.close();
      } catch (err) {
        Toast.show('Erreur lors de l\'enregistrement', 'error');
      }
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     FOND 3D — parallaxe au mouvement de la souris
  ═══════════════════════════════════════════════════════════════════════════ */
  const Background3D = {
    _starColors: ['#A855F7', '#EC4899', '#D946EF', '#F472B6', '#C026D3', '#7C3AED', '#E879F9', '#FB7185', '#A855F7', '#EC4899'],

    init() {
      this.container = document.getElementById('bg-3d');
      if (!this.container) return;
      this.layers = Array.from(this.container.querySelectorAll('.bg-3d__layer'));
      this._raf = null;
      this._mx = 0;
      this._my = 0;

      this._generateStars();
      document.addEventListener('mousemove', (e) => this._onMove(e));
      document.addEventListener('mouseleave', () => this._reset());
    },

    _generateStars() {
      this.container.querySelectorAll('.bg-3d__stars').forEach(group => {
        const count = parseInt(group.dataset.count, 10) || 10;
        const sMin  = parseFloat(group.dataset.sizeMin) || 2;
        const sMax  = parseFloat(group.dataset.sizeMax) || 4;
        for (let i = 0; i < count; i++) {
          const size  = sMin + Math.random() * (sMax - sMin);
          const color = this._starColors[Math.floor(Math.random() * this._starColors.length)];
          const star  = document.createElement('span');
          star.className = 'star';
          star.style.left   = `${Math.random() * 100}%`;
          star.style.top    = `${Math.random() * 100}%`;
          star.style.width  = `${size}px`;
          star.style.height = `${size}px`;
          star.style.background = color;
          star.style.boxShadow  = `0 0 ${size * 2.5}px ${color}`;
          star.style.animationDuration = `${2.5 + Math.random() * 4}s`;
          star.style.animationDelay    = `${Math.random() * 4}s`;
          group.appendChild(star);
        }
      });
    },

    _onMove(e) {
      const w = window.innerWidth  || 1;
      const h = window.innerHeight || 1;
      this._mx = (e.clientX / w - 0.5) * 2; // -1 → 1
      this._my = (e.clientY / h - 0.5) * 2;

      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this.layers.forEach(layer => {
          const depth = parseFloat(layer.dataset.depth) || 20;
          const x = this._mx * depth;
          const y = this._my * depth;
          layer.style.transform = `translate3d(${x}px, ${y}px, 0)`;
        });
        this.container.style.transform =
          `rotateY(${this._mx * 10}deg) rotateX(${-this._my * 10}deg)`;
      });
    },

    _reset() {
      this.layers?.forEach(layer => { layer.style.transform = ''; });
      this.container.style.transform = '';
    },
  };

  /* ═══════════════════════════════════════════════════════════════════════════
     APP – Point d'entrée
  ═══════════════════════════════════════════════════════════════════════════ */
  const App = {
    init() {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => this._boot());
      } else {
        this._boot();
      }
    },

    async _boot() {
      Background3D.init();
      Auth.init();
      // Vérifie si une session existe déjà
      try {
        const res = await Utils.send('GET_SESSION');
        if (res.success && res.username) {
          this._onLogin(res.username);
        } else {
          this._onLogout();
        }
      } catch {
        this._onLogout();
      }
    },

    _onLogin(username) {
      document.getElementById('auth-screen').hidden = true;
      document.getElementById('app').hidden = false;
      // Affiche le nom dans le header
      const el = document.getElementById('header-username');
      if (el) el.textContent = '@' + username;
      // Initialise l'app principale
      if (!this._appBooted) {
        TabManager.init();
        Generator.init();
        VideoGen.init();
        History.init();
        Stats.init();
        Settings.init();
        this._listenParentMessages();
        this._wireCloseButton();
        this._appBooted = true;
      }
      // Recharge TOUT l'état propre au compte : évite qu'un changement de compte
      // laisse fuiter la clé API, les paramètres, la vidéo ou l'historique du précédent.
      try { Generator._reset(); } catch {}
      try { VideoGen.reset(); }  catch {}
      try { Settings.load(); }   catch {}
      // Met à jour l'avatar dans les paramètres
      const avatar = document.getElementById('settings-avatar');
      const uname  = document.getElementById('settings-username');
      if (avatar) avatar.textContent = username[0].toUpperCase();
      if (uname)  uname.textContent  = username;
      History.refresh();
      console.log('[Stidia] Connecté :', username);
    },

    _onLogout() {
      document.getElementById('auth-screen').hidden = false;
      document.getElementById('app').hidden = true;
      // Réinitialise les champs
      ['login-username','login-password','reg-username','reg-password','reg-confirm','reg-apikey']
        .forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
      Auth._showForm('login');
    },

    /**
     * Câble le bouton croix (X) de l'en-tête pour fermer le panneau.
     * Envoie CLOSE_PANEL à content.js, qui referme l'iframe.
     */
    _wireCloseButton() {
      const btnClose = document.getElementById('btn-close');
      if (!btnClose) return;
      btnClose.addEventListener('click', () => {
        Utils.postToParent({
          source: 'tiktok-ai-sidebar',
          action: 'CLOSE_PANEL',
        });
      });
    },

    /**
     * Écoute les messages de content.js (via l'iframe parent).
     */
    _listenParentMessages() {
      window.addEventListener('message', (event) => {
        // Sécurité : n'accepter que les messages venant de la fenêtre parente (content.js)
        if (event.source !== window.parent) return;
        if (!event.data || event.data.source !== 'tiktok-ai-content') return;
        // Mémorise l'origine réelle du parent pour cibler nos réponses (plus de wildcard)
        if (!Utils._parentOrigin && event.origin && event.origin !== 'null') {
          Utils._parentOrigin = event.origin;
        }

        const { action, payload } = event.data;

        switch (action) {
          case 'PANEL_OPENED':
            // Rafraîchit les données à chaque ouverture
            History.refresh();
            break;

          case 'PAGE_CONTEXT':
            // Remplit automatiquement le prompt avec le contexte TikTok
            if (payload?.type && Generator.promptInput.value === '') {
              this._autofillFromContext(payload);
            }
            break;

          case 'REFRESH':
            History.refresh();
            break;
        }
      });

      // Demande le contexte de la page à l'ouverture
      Utils.postToParent({
        source: 'tiktok-ai-sidebar',
        action: 'GET_PAGE_CONTEXT',
      });
    },

    /**
     * Pré-remplit le prompt si on est sur une page vidéo TikTok.
     */
    _autofillFromContext(ctx) {
      if (ctx.type === 'video' && ctx.videoDescription) {
        const hint = `Aide-moi à créer une vidéo TikTok similaire à : "${ctx.videoDescription}"`;
        Generator.promptInput.value = hint;
        Generator.promptInput.dispatchEvent(new Event('input'));
      }
    },

  };

  // Lancement
  App.init();

})();
